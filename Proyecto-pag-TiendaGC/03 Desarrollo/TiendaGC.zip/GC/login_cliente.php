<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = trim($_POST['correo'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($pdo) {
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE correo = ? AND activo = 1");
        $stmt->execute([$correo]);
        $usuario = $stmt->fetch();

        if ($usuario && password_verify($password, $usuario['password_hash'])) {
            $_SESSION['usuario_id']     = $usuario['id'];
            $_SESSION['usuario_nombre'] = $usuario['nombre'];
            $_SESSION['usuario_rol']    = $usuario['rol'];
            $_SESSION['cliente_id']     = $usuario['id'];
            $_SESSION['cliente_nombre'] = $usuario['nombre'];
            header('Location: index.php');
            exit;
        }
    }
    // El mensaje de error se traduce después de cargar lang.php vía header
    $error = 'error_credenciales';
}

include 'includes/header.php';
?>

<section class="container my-5" style="max-width: 420px;">
    <h1 class="h4 mb-4"><?= t('login_titulo') ?></h1>

    <?php if ($error): ?>
        <div class="alert alert-danger small"><?= htmlspecialchars(t($error)) ?></div>
    <?php endif; ?>

    <form method="post" class="bg-white p-4 rounded shadow-sm">
        <div class="mb-3">
            <label class="form-label"><?= t('correo') ?></label>
            <input type="email" name="correo" class="form-control" required autofocus>
        </div>
        <div class="mb-4">
            <label class="form-label"><?= t('contrasena') ?></label>
            <input type="password" name="password" class="form-control" required>
        </div>
        <button type="submit" class="btn btn-danger w-100"><?= t('entrar') ?></button>
    </form>

    <p class="text-center small mt-3">
        <?= t('no_tienes_cuenta') ?> <a href="registro.php"><?= t('registrate') ?></a>
    </p>
</section>

<?php include 'includes/footer.php'; ?>
