<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';
require_once 'includes/cifrado.php';

if ((empty($_SESSION['usuario_id']) && empty($_SESSION['cliente_id'])) || empty($_SESSION['carrito']) || $_SERVER['REQUEST_METHOD'] !== 'POST' || !$pdo) {
    header('Location: carrito.php');
    exit;
}

$direccion = trim($_POST['direccion'] ?? '');
$ciudad = trim($_POST['ciudad'] ?? '');
$metodoPago = trim($_POST['metodo_pago'] ?? '');
$numeroTarjeta = preg_replace('/\D/', '', $_POST['numero_tarjeta'] ?? '');

if ($direccion === '' || $ciudad === '' || $metodoPago === '') {
    die('Faltan datos obligatorios. <a href="checkout.php">Volver al checkout</a>');
}

// Dato SENSIBLE: nunca guardamos el número completo de la tarjeta ni el CVV.
$referenciaPago = null;
if ($metodoPago === 'Tarjeta' && strlen($numeroTarjeta) >= 4) {
    $referenciaPago = 'Tarjeta terminada en ' . substr($numeroTarjeta, -4);
} elseif ($metodoPago !== 'Tarjeta') {
    $referenciaPago = $metodoPago;
}

$direccionCompleta = $direccion . ', ' . $ciudad;

// Recalculamos precios y validamos stock desde la BD
$ids = array_keys($_SESSION['carrito']);
$marcadores = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("
    SELECT id, nombre, precio, descuento, stock
    FROM productos
    WHERE id IN ($marcadores) AND estado = 'activo'
");
$stmt->execute($ids);
$productosCarrito = $stmt->fetchAll();

$total = 0;
$detalle = [];
$erroresStock = [];

foreach ($productosCarrito as $p) {
    $cantidad = (int) ($_SESSION['carrito'][$p['id']] ?? 0);
    $stock = (int) $p['stock'];

    if ($cantidad <= 0) {
        continue;
    }
    if ($cantidad > $stock) {
        $erroresStock[] = htmlspecialchars($p['nombre']) . " (pediste $cantidad, hay $stock)";
        continue;
    }

    $precioFinal = $p['precio'] * (1 - ($p['descuento'] ?? 0) / 100);
    $subtotal = $precioFinal * $cantidad;
    $total += $subtotal;

    $detalle[] = [
        'producto_id' => $p['id'],
        'nombre' => $p['nombre'],
        'precio_unitario' => $precioFinal,
        'cantidad' => $cantidad,
        'subtotal' => $subtotal,
    ];
}

if (!empty($erroresStock)) {
    die(
        'No hay suficiente inventario para completar el pedido:<br>• '
        . implode('<br>• ', $erroresStock)
        . '<br><br><a href="carrito.php">Volver al carrito</a>'
    );
}

if (empty($detalle)) {
    header('Location: carrito.php');
    exit;
}

/** Genera un código único tipo "GC-7K2P9XAB" */
function generarReferenciaPedido(PDO $pdo): string
{
    do {
        $referencia = 'GC-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $stmt = $pdo->prepare("SELECT id FROM pedidos WHERE numero_referencia = ?");
        $stmt->execute([$referencia]);
    } while ($stmt->fetch());

    return $referencia;
}

$numeroReferencia = generarReferenciaPedido($pdo);

try {
    $pdo->beginTransaction();

    // 1. Crear el pedido
    $stmt = $pdo->prepare("
        INSERT INTO pedidos (usuario_id, numero_referencia, direccion_envio_cifrada, metodo_pago, referencia_pago, total, estado)
        VALUES (?, ?, ?, ?, ?, ?, 'Pendiente')
    ");
    $stmt->execute([
        ($_SESSION['usuario_id'] ?? $_SESSION['cliente_id']),
        $numeroReferencia,
        cifrar($direccionCompleta),
        $metodoPago,
        $referenciaPago,
        $total,
    ]);
    $pedidoId = (int) $pdo->lastInsertId();

    // 2. Detalle del pedido + descontar inventario
    $stmtDetalle = $pdo->prepare("
        INSERT INTO detalle_pedido (pedido_id, producto_id, nombre_producto, precio_unitario, cantidad, subtotal)
        VALUES (?, ?, ?, ?, ?, ?)
    ");
    $stmtStock = $pdo->prepare("
        UPDATE productos
        SET stock = stock - ?
        WHERE id = ? AND stock >= ?
    ");

    foreach ($detalle as $d) {
        $stmtDetalle->execute([
            $pedidoId,
            $d['producto_id'],
            $d['nombre'],
            $d['precio_unitario'],
            $d['cantidad'],
            $d['subtotal'],
        ]);

        // Actualizar inventario (punto 2.3 del PDF)
        $stmtStock->execute([
            $d['cantidad'],
            $d['producto_id'],
            $d['cantidad'],
        ]);

        if ($stmtStock->rowCount() === 0) {
            throw new Exception('Stock insuficiente al descontar el producto ID ' . $d['producto_id']);
        }
    }

    $pdo->commit();
} catch (Exception $e) {
    $pdo->rollBack();
    die('Ocurrió un error al procesar tu pedido (posible falta de stock). <a href="carrito.php">Volver al carrito</a>');
}

// El carrito se vacía solo después de guardar el pedido correctamente
$_SESSION['carrito'] = [];

header('Location: pedido_confirmado.php?id=' . $pedidoId);
exit;