<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$estadosPermitidos = ['Pendiente', 'En proceso', 'Enviado', 'Entregado', 'Cancelado'];

$id = (int) ($_POST['id'] ?? 0);
$estado = $_POST['estado'] ?? '';

if ($pdo && $id > 0 && in_array($estado, $estadosPermitidos, true)) {
    $stmt = $pdo->prepare("UPDATE pedidos SET estado = ? WHERE id = ?");
    $stmt->execute([$estado, $id]);
}

header('Location: pedidos.php');
exit;