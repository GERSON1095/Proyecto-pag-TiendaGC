<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$productos = [];
$errorConexion = !$pdo;

if ($pdo) {
    try {
        $productos = $pdo->query("
            SELECT p.*, c.nombre AS categoria_nombre
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            ORDER BY p.id DESC
        ")->fetchAll();
    } catch (PDOException $e) {
        $errorConexion = true;
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Administrar productos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">GC<span class="text-danger">.</span> Admin</span>
        <div>
            <a href="dashboard.php" class="btn btn-sm btn-outline-light me-2">Dashboard</a>
            <a href="productos.php" class="btn btn-sm btn-outline-light me-2">Productos</a>
            <a href="pedidos.php" class="btn btn-sm btn-outline-light me-2">Pedidos</a>
            <a href="../index.php" class="btn btn-sm btn-outline-light me-2">Ver tienda</a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h1 class="h4 mb-0">Productos (<?= count($productos) ?>)</h1>
        <a href="nuevo.php" class="btn btn-danger"><i class="bi bi-plus-lg"></i> Agregar producto</a>
    </div>

    <?php if ($errorConexion): ?>
        <div class="alert alert-warning">
            No se pudo conectar a la base de datos <code>gc_tienda</code>. Verifica que MySQL esté
            corriendo en XAMPP y que hayas importado el esquema actualizado.
        </div>
    <?php elseif (empty($productos)): ?>
        <div class="alert alert-info">Todavía no hay productos. Da clic en "Agregar producto" para crear el primero.</div>
    <?php else: ?>
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Foto</th>
                        <th>Nombre</th>
                        <th>Marca</th>
                        <th>Categoría</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Mín.</th>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($productos as $p): ?>
                        <?php
                        $stockBajo = ((int) $p['stock'] <= (int) $p['stock_minimo']);
                        ?>
                        <tr class="<?= $stockBajo ? 'table-warning' : '' ?>">
                            <td style="width:60px;">
                                <?php if (!empty($p['imagen'])): ?>
                                    <img src="../<?= htmlspecialchars($p['imagen']) ?>" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:8px;">
                                <?php else: ?>
                                    <div class="bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;border-radius:8px;">
                                        <i class="bi bi-image text-secondary"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?= htmlspecialchars($p['nombre']) ?>
                                <?php if ($stockBajo): ?>
                                    <span class="badge bg-warning text-dark ms-1">Stock bajo</span>
                                <?php endif; ?>
                            </td>
                            <td><?= htmlspecialchars($p['marca']) ?></td>
                            <td><?= htmlspecialchars($p['categoria_nombre'] ?? '—') ?></td>
                            <td>$<?= number_format((float) $p['precio'], 0, ',', '.') ?></td>
                            <td><?= (int) $p['stock'] ?></td>
                            <td><?= (int) $p['stock_minimo'] ?></td>
                            <td>
                                <?php if (($p['estado'] ?? 'activo') === 'activo'): ?>
                                    <span class="badge bg-success">Activo</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactivo</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-end">
                                <a href="editar.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-secondary me-1">
                                    <i class="bi bi-pencil"></i>
                                </a>
                                <a href="eliminar.php?id=<?= (int) $p['id'] ?>"
                                   class="btn btn-sm btn-outline-danger"
                                   onclick="return confirm('¿Eliminar este producto? Esta acción no se puede deshacer.');">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

</body>
</html>