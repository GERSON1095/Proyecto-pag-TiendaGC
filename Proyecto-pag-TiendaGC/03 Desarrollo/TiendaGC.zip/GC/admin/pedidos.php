<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';
require_once '../includes/cifrado.php';

$estadosPosibles = ['Pendiente', 'En proceso', 'Enviado', 'Entregado', 'Cancelado'];

$pedidos = [];
$errorConexion = !$pdo;

if ($pdo) {
    try {
            $pedidos = $pdo->query("
            SELECT p.*, c.nombre AS cliente_nombre, c.correo AS cliente_correo
            FROM pedidos p
            JOIN usuarios c ON c.id = p.usuario_id
            ORDER BY p.creado_en DESC
        ")->fetchAll();
    } catch (PDOException $e) {
        $errorConexion = true;
    }
}

function colorEstado(string $estado): string
{
    return match ($estado) {
        'Pendiente' => 'bg-warning text-dark',
        'En proceso' => 'bg-info text-dark',
        'Enviado' => 'bg-primary',
        'Entregado' => 'bg-success',
        'Cancelado' => 'bg-danger',
        default => 'bg-secondary',
    };
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Pedidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">GC<span class="text-danger">.</span> Admin</span>
        <div>
            <a href="dashboard.php" class="btn btn-sm btn-outline-light me-2">Dashboard</a>
            <a href="productos.php" class="btn btn-sm btn-outline-light me-2">Productos</a>
            <a href="pedidos.php" class="btn btn-sm btn-outline-light me-2">Pedidos</a>
            <a href="../index.php" class="btn btn-sm btn-outline-light me-2">Ver tienda</a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container">
    <h1 class="h4 mb-3">Pedidos (<?= count($pedidos) ?>)</h1>

    <?php if ($errorConexion): ?>
        <div class="alert alert-warning">No se pudo conectar a la base de datos.</div>
    <?php elseif (empty($pedidos)): ?>
        <div class="alert alert-info">Todavía no hay pedidos registrados.</div>
    <?php else: ?>
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>Pedido</th>
                        <th>Referencia</th>
                        <th>Cliente</th>
                        <th>Fecha</th>
                        <th>Dirección de envío</th>
                        <th>Pago</th>
                        <th>Total</th>
                        <th>Estado</th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidos as $p): ?>
                        <tr>
                            <td>#<?= (int) $p['id'] ?></td>
                            <td><code><?= htmlspecialchars($p['numero_referencia']) ?></code></td>
                            <td>
                                <?= htmlspecialchars($p['cliente_nombre']) ?>
                                <div class="small text-secondary"><?= htmlspecialchars($p['cliente_correo']) ?></div>
                            </td>
                            <td class="small"><?= date('d/m/Y H:i', strtotime($p['creado_en'])) ?></td>
                            <td class="small"><?= htmlspecialchars(descifrar($p['direccion_envio_cifrada'])) ?></td>
                            <td class="small"><?= htmlspecialchars($p['referencia_pago'] ?? $p['metodo_pago']) ?></td>
                            <td>$<?= number_format((float) $p['total'], 0, ',', '.') ?></td>
                            <td><span class="badge <?= colorEstado($p['estado']) ?>"><?= htmlspecialchars($p['estado']) ?></span></td>
                            <td style="min-width: 200px;">
                                <form action="actualizar_estado_pedido.php" method="post" class="d-flex gap-1">
                                    <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                                    <select name="estado" class="form-select form-select-sm">
                                        <?php foreach ($estadosPosibles as $estado): ?>
                                            <option value="<?= $estado ?>" <?= $p['estado'] === $estado ? 'selected' : '' ?>><?= $estado ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="btn btn-sm btn-dark">Guardar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

</body>
</html>