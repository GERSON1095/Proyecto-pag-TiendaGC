<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: productos.php');
    exit;
}

if (!$pdo) {
    die('No hay conexión a la base de datos. Verifica XAMPP e importa el esquema actualizado.');
}

$nombre       = trim($_POST['nombre'] ?? '');
$marca        = trim($_POST['marca'] ?? '');
$categoriaId  = (int) ($_POST['categoria_id'] ?? 0);
$descripcion  = trim($_POST['descripcion'] ?? '');
$tallas       = trim($_POST['tallas'] ?? '');
$colores      = trim($_POST['colores'] ?? '');
$precio       = (float) ($_POST['precio'] ?? 0);
$descuento    = max(0, min(90, (int) ($_POST['descuento'] ?? 0)));
$stock        = max(0, (int) ($_POST['stock'] ?? 0));
$stockMinimo  = max(0, (int) ($_POST['stock_minimo'] ?? 5));
$estado       = ($_POST['estado'] ?? 'activo') === 'inactivo' ? 'inactivo' : 'activo';

if ($nombre === '' || $marca === '' || $categoriaId <= 0 || $precio <= 0) {
    die('Faltan datos obligatorios (nombre, marca, categoría o precio). Vuelve atrás e inténtalo de nuevo.');
}

// --- Subida de la imagen ---
$rutaImagen = null;
if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];
    $extension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));

    if (in_array($extension, $extensionesPermitidas, true)) {
        $carpetaDestino = __DIR__ . '/../img/productos/';
        if (!is_dir($carpetaDestino)) {
            mkdir($carpetaDestino, 0755, true);
        }

        $nombreArchivo = uniqid('prod_', true) . '.' . $extension;

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $carpetaDestino . $nombreArchivo)) {
            $rutaImagen = 'img/productos/' . $nombreArchivo;
        }
    }
}

$stmt = $pdo->prepare("
    INSERT INTO productos (
        nombre, marca, categoria_id, descripcion, tallas, colores,
        precio, descuento, stock, stock_minimo, imagen, estado
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
");
$stmt->execute([
    $nombre,
    $marca,
    $categoriaId,
    $descripcion !== '' ? $descripcion : null,
    $tallas !== '' ? $tallas : null,
    $colores !== '' ? $colores : null,
    $precio,
    $descuento,
    $stock,
    $stockMinimo,
    $rutaImagen,
    $estado,
]);

header('Location: productos.php');
exit;