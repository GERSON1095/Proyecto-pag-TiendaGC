<?php
require_once '../includes/db.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo   = trim($_POST['correo'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($pdo) {
        $stmt = $pdo->prepare("
            SELECT * FROM usuarios
            WHERE correo = ? AND rol = 'administrador' AND activo = 1
        ");
        $stmt->execute([$correo]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password_hash'])) {
            $_SESSION['admin_autenticado'] = true;
            $_SESSION['admin_id']          = $admin['id'];
            $_SESSION['admin_nombre']      = $admin['nombre'];
            header('Location: dashboard.php');
            exit;
        }
    }
    $error = 'Credenciales incorrectas o no tienes rol de administrador.';
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Acceso administrador</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-dark d-flex align-items-center justify-content-center" style="min-height:100vh;">
    <div class="card p-4 shadow" style="width: 340px;">
        <h1 class="h5 text-center mb-3">Panel administrador GC</h1>

        <?php if ($error): ?>
            <div class="alert alert-danger py-2 small"><?= htmlspecialchars($error) ?></div>
        <?php endif; ?>

        <form method="post">
            <div class="mb-3">
                <label class="form-label small">Correo</label>
                <input type="email" name="correo" class="form-control" required autofocus>
            </div>
            <div class="mb-3">
                <label class="form-label small">Contraseña</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-dark w-100">Entrar</button>
        </form>
        <a href="../index.php" class="d-block text-center small mt-3 text-secondary">← Volver a la tienda</a>
    </div>
</body>
</html>