<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$errorConexion = !$pdo;

$totalUsuarios = 0;
$totalProductos = 0;
$totalPedidos = 0;
$productosBajoStock = [];
$ultimosPedidos = [];
$pedidosPorEstado = [];

if ($pdo) {
    try {
        $totalUsuarios  = (int) $pdo->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
        $totalProductos = (int) $pdo->query("SELECT COUNT(*) FROM productos")->fetchColumn();
        $totalPedidos   = (int) $pdo->query("SELECT COUNT(*) FROM pedidos")->fetchColumn();

        // Productos con inventario bajo (stock <= stock_minimo)
        $productosBajoStock = $pdo->query("
            SELECT p.id, p.nombre, p.marca, p.stock, p.stock_minimo, c.nombre AS categoria
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            WHERE p.stock <= p.stock_minimo
            ORDER BY p.stock ASC
        ")->fetchAll();

        // Últimos pedidos
        $ultimosPedidos = $pdo->query("
            SELECT p.id, p.numero_referencia, p.total, p.estado, p.creado_en,
                   u.nombre AS usuario_nombre, u.correo AS usuario_correo
            FROM pedidos p
            JOIN usuarios u ON u.id = p.usuario_id
            ORDER BY p.creado_en DESC
            LIMIT 8
        ")->fetchAll();

        // Conteo por estado
        $filasEstado = $pdo->query("
            SELECT estado, COUNT(*) AS cantidad
            FROM pedidos
            GROUP BY estado
        ")->fetchAll();
        foreach ($filasEstado as $fila) {
            $pedidosPorEstado[$fila['estado']] = (int) $fila['cantidad'];
        }
    } catch (PDOException $e) {
        $errorConexion = true;
    }
}

function colorEstado(string $estado): string
{
    return match ($estado) {
        'Pendiente'  => 'bg-warning text-dark',
        'En proceso' => 'bg-info text-dark',
        'Enviado'    => 'bg-primary',
        'Entregado'  => 'bg-success',
        'Cancelado'  => 'bg-danger',
        default      => 'bg-secondary',
    };
}

$estadosPosibles = ['Pendiente', 'En proceso', 'Enviado', 'Entregado', 'Cancelado'];
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Panel administrativo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">GC<span class="text-danger">.</span> Admin</span>
        <div>
            <a href="dashboard.php" class="btn btn-sm btn-light me-2">Dashboard</a>
            <a href="productos.php" class="btn btn-sm btn-outline-light me-2">Productos</a>
            <a href="pedidos.php" class="btn btn-sm btn-outline-light me-2">Pedidos</a>
            <a href="../index.php" class="btn btn-sm btn-outline-light me-2">Ver tienda</a>
            <a href="logout.php" class="btn btn-sm btn-outline-danger">Cerrar sesión</a>
        </div>
    </div>
</nav>

<div class="container pb-5">
    <h1 class="h4 mb-4">Panel administrativo</h1>

    <?php if ($errorConexion): ?>
        <div class="alert alert-warning">
            No se pudo conectar a la base de datos. Verifica XAMPP y el esquema de <code>gc_tienda</code>.
        </div>
    <?php else: ?>

        <!-- Tarjetas de resumen -->
        <div class="row g-3 mb-4">
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-secondary small">Usuarios</div>
                        <div class="fs-3 fw-bold"><?= $totalUsuarios ?></div>
                        <i class="bi bi-people text-primary"></i>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-secondary small">Productos</div>
                        <div class="fs-3 fw-bold"><?= $totalProductos ?></div>
                        <i class="bi bi-box-seam text-success"></i>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-body">
                        <div class="text-secondary small">Pedidos</div>
                        <div class="fs-3 fw-bold"><?= $totalPedidos ?></div>
                        <i class="bi bi-receipt text-danger"></i>
                    </div>
                </div>
            </div>
            <div class="col-6 col-md-3">
                <div class="card border-0 shadow-sm h-100 <?= count($productosBajoStock) > 0 ? 'border border-warning' : '' ?>">
                    <div class="card-body">
                        <div class="text-secondary small">Inventario bajo</div>
                        <div class="fs-3 fw-bold text-warning"><?= count($productosBajoStock) ?></div>
                        <i class="bi bi-exclamation-triangle text-warning"></i>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- Estados de pedidos -->
            <div class="col-md-4">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white fw-bold">Estado de los pedidos</div>
                    <div class="card-body">
                        <?php if ($totalPedidos === 0): ?>
                            <p class="text-secondary small mb-0">Aún no hay pedidos registrados.</p>
                        <?php else: ?>
                            <ul class="list-group list-group-flush">
                                <?php foreach ($estadosPosibles as $est): ?>
                                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                                        <span class="badge <?= colorEstado($est) ?>"><?= $est ?></span>
                                        <span class="fw-bold"><?= $pedidosPorEstado[$est] ?? 0 ?></span>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Productos con inventario bajo -->
            <div class="col-md-8">
                <div class="card border-0 shadow-sm h-100">
                    <div class="card-header bg-white d-flex justify-content-between align-items-center">
                        <span class="fw-bold">Productos con inventario bajo</span>
                        <a href="productos.php" class="small">Ver todos</a>
                    </div>
                    <div class="card-body p-0">
                        <?php if (empty($productosBajoStock)): ?>
                            <p class="text-secondary small p-3 mb-0">Ningún producto está por debajo del stock mínimo.</p>
                        <?php else: ?>
                            <div class="table-responsive">
                                <table class="table table-sm align-middle mb-0">
                                    <thead class="table-light">
                                        <tr>
                                            <th>Producto</th>
                                            <th>Categoría</th>
                                            <th>Stock</th>
                                            <th>Mínimo</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($productosBajoStock as $p): ?>
                                            <tr class="table-warning">
                                                <td>
                                                    <div class="fw-semibold"><?= htmlspecialchars($p['nombre']) ?></div>
                                                    <div class="small text-secondary"><?= htmlspecialchars($p['marca']) ?></div>
                                                </td>
                                                <td><?= htmlspecialchars($p['categoria'] ?? '—') ?></td>
                                                <td class="fw-bold"><?= (int) $p['stock'] ?></td>
                                                <td><?= (int) $p['stock_minimo'] ?></td>
                                                <td>
                                                    <a href="editar.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-secondary">
                                                        Editar
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Últimos pedidos -->
        <div class="card border-0 shadow-sm mt-4">
            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                <span class="fw-bold">Últimos pedidos registrados</span>
                <a href="pedidos.php" class="small">Ver todos</a>
            </div>
            <div class="card-body p-0">
                <?php if (empty($ultimosPedidos)): ?>
                    <p class="text-secondary small p-3 mb-0">Todavía no hay pedidos.</p>
                <?php else: ?>
                    <div class="table-responsive">
                        <table class="table align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    <th>Referencia</th>
                                    <th>Cliente</th>
                                    <th>Total</th>
                                    <th>Estado</th>
                                    <th>Fecha</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ultimosPedidos as $ped): ?>
                                    <tr>
                                        <td>
                                            <code><?= htmlspecialchars($ped['numero_referencia']) ?></code>
                                        </td>
                                        <td>
                                            <div><?= htmlspecialchars($ped['usuario_nombre']) ?></div>
                                            <div class="small text-secondary"><?= htmlspecialchars($ped['usuario_correo']) ?></div>
                                        </td>
                                        <td>$<?= number_format((float) $ped['total'], 0, ',', '.') ?></td>
                                        <td>
                                            <span class="badge <?= colorEstado($ped['estado']) ?>">
                                                <?= htmlspecialchars($ped['estado']) ?>
                                            </span>
                                        </td>
                                        <td class="small text-secondary">
                                            <?= date('d/m/Y H:i', strtotime($ped['creado_en'])) ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    <?php endif; ?>
</div>

</body>
</html>