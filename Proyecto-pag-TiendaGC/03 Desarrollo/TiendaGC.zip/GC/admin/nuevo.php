<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$categorias = [];
if ($pdo) {
    $categorias = $pdo->query("SELECT id, nombre FROM categorias ORDER BY nombre")->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Agregar producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">GC<span class="text-danger">.</span> Admin</span>
        <a href="productos.php" class="btn btn-sm btn-outline-light">← Volver al listado</a>
    </div>
</nav>

<div class="container" style="max-width: 640px;">
    <h1 class="h4 mb-4">Agregar producto</h1>

    <form action="guardar.php" method="post" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">

        <div class="mb-3">
            <label class="form-label">Nombre del producto</label>
            <input type="text" name="nombre" class="form-control" placeholder="Ej: Hoodie Air Jordan" required>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Marca</label>
                <input type="text" name="marca" class="form-control" placeholder="Ej: Nike" required list="marcasSugeridas">
                <datalist id="marcasSugeridas">
                    <option value="Nike"><option value="Adidas"><option value="Puma">
                </datalist>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Categoría</label>
                <select name="categoria_id" class="form-select" required>
                    <option value="">Selecciona...</option>
                    <?php foreach ($categorias as $cat): ?>
                        <option value="<?= (int) $cat['id'] ?>"><?= htmlspecialchars($cat['nombre']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" rows="3" placeholder="Descripción del producto..."></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Tallas disponibles</label>
            <input type="text" name="tallas" class="form-control" placeholder="Ej: S,M,L,XL  o  38,39,40,41">
            <div class="form-text">Sepáralas con comas. Escribe "Única" si no aplica.</div>
        </div>

        <div class="mb-3">
            <label class="form-label">Colores disponibles</label>
            <input type="text" name="colores" class="form-control" placeholder="Ej: Negro,Blanco,Rojo">
            <div class="form-text">Sepáralos con comas.</div>
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">Precio (COP)</label>
                <input type="number" name="precio" class="form-control" min="0" step="100" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Descuento (%)</label>
                <input type="number" name="descuento" class="form-control" min="0" max="90" value="0">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-select">
                    <option value="activo" selected>Activo</option>
                    <option value="inactivo">Inactivo</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Stock (cantidad disponible)</label>
                <input type="number" name="stock" class="form-control" min="0" value="10">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Stock mínimo (alerta)</label>
                <input type="number" name="stock_minimo" class="form-control" min="0" value="5">
                <div class="form-text">Se alerta cuando el stock llegue a este valor o menos.</div>
            </div>
        </div>

        <div class="mb-4">
            <label class="form-label">Foto del producto</label>
            <input type="file" name="imagen" class="form-control" accept=".jpg,.jpeg,.png,.webp">
            <div class="form-text">Formatos: JPG, PNG, WEBP.</div>
        </div>

        <button type="submit" class="btn btn-danger w-100">Guardar producto</button>
    </form>
</div>

</body>
</html>