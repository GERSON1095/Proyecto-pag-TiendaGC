<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !$pdo) {
    header('Location: productos.php');
    exit;
}

$id           = (int) ($_POST['id'] ?? 0);
$nombre       = trim($_POST['nombre'] ?? '');
$marca        = trim($_POST['marca'] ?? '');
$categoriaId  = (int) ($_POST['categoria_id'] ?? 0);
$descripcion  = trim($_POST['descripcion'] ?? '');
$tallas       = trim($_POST['tallas'] ?? '');
$colores      = trim($_POST['colores'] ?? '');
$precio       = (float) ($_POST['precio'] ?? 0);
$descuento    = max(0, min(90, (int) ($_POST['descuento'] ?? 0)));
$stock        = max(0, (int) ($_POST['stock'] ?? 0));
$stockMinimo  = max(0, (int) ($_POST['stock_minimo'] ?? 5));
$estado       = ($_POST['estado'] ?? 'activo') === 'inactivo' ? 'inactivo' : 'activo';

if ($id <= 0 || $nombre === '' || $marca === '' || $categoriaId <= 0 || $precio <= 0) {
    die('Faltan datos obligatorios. Vuelve atrás e inténtalo de nuevo.');
}

// --- Si subieron una foto nueva, reemplaza la anterior ---
$nuevaImagen = null;
if (!empty($_FILES['imagen']['name']) && $_FILES['imagen']['error'] === UPLOAD_ERR_OK) {
    $extensionesPermitidas = ['jpg', 'jpeg', 'png', 'webp'];
    $extension = strtolower(pathinfo($_FILES['imagen']['name'], PATHINFO_EXTENSION));

    if (in_array($extension, $extensionesPermitidas, true)) {
        $carpetaDestino = __DIR__ . '/../img/productos/';
        if (!is_dir($carpetaDestino)) {
            mkdir($carpetaDestino, 0755, true);
        }

        $nombreArchivo = uniqid('prod_', true) . '.' . $extension;

        if (move_uploaded_file($_FILES['imagen']['tmp_name'], $carpetaDestino . $nombreArchivo)) {
            $nuevaImagen = 'img/productos/' . $nombreArchivo;

            $stmtImg = $pdo->prepare("SELECT imagen FROM productos WHERE id = ?");
            $stmtImg->execute([$id]);
            $imagenVieja = $stmtImg->fetchColumn();
            if ($imagenVieja) {
                $rutaVieja = __DIR__ . '/../' . $imagenVieja;
                if (is_file($rutaVieja)) {
                    unlink($rutaVieja);
                }
            }
        }
    }
}

if ($nuevaImagen) {
    $stmt = $pdo->prepare("
        UPDATE productos SET
            nombre=?, marca=?, categoria_id=?, descripcion=?, tallas=?, colores=?,
            precio=?, descuento=?, stock=?, stock_minimo=?, imagen=?, estado=?
        WHERE id=?
    ");
    $stmt->execute([
        $nombre, $marca, $categoriaId,
        $descripcion !== '' ? $descripcion : null,
        $tallas !== '' ? $tallas : null,
        $colores !== '' ? $colores : null,
        $precio, $descuento, $stock, $stockMinimo, $nuevaImagen, $estado, $id,
    ]);
} else {
    $stmt = $pdo->prepare("
        UPDATE productos SET
            nombre=?, marca=?, categoria_id=?, descripcion=?, tallas=?, colores=?,
            precio=?, descuento=?, stock=?, stock_minimo=?, estado=?
        WHERE id=?
    ");
    $stmt->execute([
        $nombre, $marca, $categoriaId,
        $descripcion !== '' ? $descripcion : null,
        $tallas !== '' ? $tallas : null,
        $colores !== '' ? $colores : null,
        $precio, $descuento, $stock, $stockMinimo, $estado, $id,
    ]);
}

header('Location: productos.php');
exit;