<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$id = (int) ($_GET['id'] ?? 0);

if ($pdo && $id > 0) {
    // Borramos primero la imagen física, si existe, para no dejar archivos huérfanos
    $stmt = $pdo->prepare("SELECT imagen FROM productos WHERE id = ?");
    $stmt->execute([$id]);
    $imagen = $stmt->fetchColumn();

    if ($imagen) {
        $rutaFisica = __DIR__ . '/../' . $imagen;
        if (is_file($rutaFisica)) {
            unlink($rutaFisica);
        }
    }

    $stmt = $pdo->prepare("DELETE FROM productos WHERE id = ?");
    $stmt->execute([$id]);
}

header('Location: productos.php');
exit;