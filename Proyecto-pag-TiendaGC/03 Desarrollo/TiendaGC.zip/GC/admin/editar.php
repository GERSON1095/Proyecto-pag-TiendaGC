<?php
require_once '../includes/auth.php';
requiereLogin();
require_once '../includes/db.php';

$id = (int) ($_GET['id'] ?? 0);
$producto = null;
$categorias = [];

if ($pdo && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM productos WHERE id = ?");
    $stmt->execute([$id]);
    $producto = $stmt->fetch();
    $categorias = $pdo->query("SELECT id, nombre FROM categorias ORDER BY nombre")->fetchAll();
}

if (!$producto) {
    header('Location: productos.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | Editar producto</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
        <span class="navbar-brand fw-bold">GC<span class="text-danger">.</span> Admin</span>
        <a href="productos.php" class="btn btn-sm btn-outline-light">← Volver al listado</a>
    </div>
</nav>

<div class="container" style="max-width: 640px;">
    <h1 class="h4 mb-4">Editar producto</h1>

    <form action="actualizar.php" method="post" enctype="multipart/form-data" class="bg-white p-4 rounded shadow-sm">
        <input type="hidden" name="id" value="<?= (int) $producto['id'] ?>">

        <div class="mb-3">
            <label class="form-label">Nombre del producto</label>
            <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($producto['nombre']) ?>" required>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Marca</label>
                <input type="text" name="marca" class="form-control" value="<?= htmlspecialchars($producto['marca']) ?>" required list="marcasSugeridas">
                <datalist id="marcasSugeridas">
                    <option value="Nike"><option value="Adidas"><option value="Puma">
                </datalist>
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Categoría</label>
                <select name="categoria_id" class="form-select" required>
                    <?php foreach ($categorias as $cat): ?>
                        <option value="<?= (int) $cat['id'] ?>"
                            <?= (int) $producto['categoria_id'] === (int) $cat['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($cat['nombre']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Descripción</label>
            <textarea name="descripcion" class="form-control" rows="3"><?= htmlspecialchars($producto['descripcion'] ?? '') ?></textarea>
        </div>

        <div class="mb-3">
            <label class="form-label">Tallas disponibles</label>
            <input type="text" name="tallas" class="form-control" value="<?= htmlspecialchars($producto['tallas'] ?? '') ?>" placeholder="Ej: S,M,L,XL">
        </div>

        <div class="mb-3">
            <label class="form-label">Colores disponibles</label>
            <input type="text" name="colores" class="form-control" value="<?= htmlspecialchars($producto['colores'] ?? '') ?>" placeholder="Ej: Negro,Blanco,Rojo">
        </div>

        <div class="row">
            <div class="col-md-4 mb-3">
                <label class="form-label">Precio (COP)</label>
                <input type="number" name="precio" class="form-control" min="0" step="100" value="<?= (float) $producto['precio'] ?>" required>
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Descuento (%)</label>
                <input type="number" name="descuento" class="form-control" min="0" max="90" value="<?= (int) $producto['descuento'] ?>">
            </div>
            <div class="col-md-4 mb-3">
                <label class="form-label">Estado</label>
                <select name="estado" class="form-select">
                    <option value="activo" <?= ($producto['estado'] ?? 'activo') === 'activo' ? 'selected' : '' ?>>Activo</option>
                    <option value="inactivo" <?= ($producto['estado'] ?? '') === 'inactivo' ? 'selected' : '' ?>>Inactivo</option>
                </select>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 mb-3">
                <label class="form-label">Stock (cantidad disponible)</label>
                <input type="number" name="stock" class="form-control" min="0" value="<?= (int) $producto['stock'] ?>">
            </div>
            <div class="col-md-6 mb-3">
                <label class="form-label">Stock mínimo (alerta)</label>
                <input type="number" name="stock_minimo" class="form-control" min="0" value="<?= (int) ($producto['stock_minimo'] ?? 5) ?>">
            </div>
        </div>

        <div class="mb-2">
            <label class="form-label">Foto actual</label><br>
            <?php if (!empty($producto['imagen'])): ?>
                <img src="../<?= htmlspecialchars($producto['imagen']) ?>" alt="" style="width:90px;height:90px;object-fit:cover;border-radius:10px;">
            <?php else: ?>
                <span class="text-secondary small">Sin foto todavía</span>
            <?php endif; ?>
        </div>

        <div class="mb-4">
            <label class="form-label">Reemplazar foto (opcional)</label>
            <input type="file" name="imagen" class="form-control" accept=".jpg,.jpeg,.png,.webp">
            <div class="form-text">Solo súbela si quieres cambiar la foto actual.</div>
        </div>

        <button type="submit" class="btn btn-danger w-100">Guardar cambios</button>
    </form>
</div>

</body>
</html>