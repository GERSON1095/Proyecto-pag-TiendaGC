<?php
require_once 'includes/db.php';

// Datos de ejemplo del mes. Si ya tienes la tabla atenciones_chatbot poblada
// (se llena automáticamente a medida que los clientes usan el chatbot),
// reemplaza este bloque por las consultas reales comentadas más abajo.
$totalAtendidos = 348;
$porTipo = ['Producto' => 140, 'Pedido' => 95, 'Pago' => 48, 'Devolución' => 35, 'Otro' => 30];
$calificaciones = ['Excelente' => 58, 'Buena' => 27, 'Regular' => 10, 'Mala' => 5]; // en %
$promedioMes = 4.3;
$promedioMesAnterior = 4.1;

if ($pdo) {
    try {
        $total = $pdo->query("
            SELECT COUNT(*) FROM atenciones_chatbot
            WHERE MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE())
        ")->fetchColumn();

        if ($total > 0) {
            $totalAtendidos = (int) $total;

            $tipos = $pdo->query("
                SELECT tipo_consulta, COUNT(*) as total FROM atenciones_chatbot
                WHERE MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE())
                GROUP BY tipo_consulta
            ")->fetchAll();
            $porTipo = [];
            foreach ($tipos as $t) {
                $porTipo[ucfirst($t['tipo_consulta'])] = (int) $t['total'];
            }

            $califs = $pdo->query("
                SELECT calificacion, COUNT(*) as total FROM atenciones_chatbot
                WHERE calificacion IS NOT NULL
                  AND MONTH(fecha) = MONTH(CURDATE()) AND YEAR(fecha) = YEAR(CURDATE())
                GROUP BY calificacion
            ")->fetchAll();
            if ($califs) {
                $calificaciones = [];
                foreach ($califs as $c) {
                    $calificaciones[$c['calificacion']] = (int) $c['total'];
                }
            }
        }
    } catch (PDOException $e) {
        // Si la tabla aún no existe, seguimos usando los datos de ejemplo.
    }
}

$sugerencias = [
    "El 5% de calificaciones 'Mala' se concentra en consultas de devolución: reforzar el flujo del chatbot para este caso.",
    "Los tiempos de respuesta en horas pico (6pm–9pm) generan más quejas: evaluar ampliar el soporte humano en ese horario.",
    "Varios comentarios piden más información de disponibilidad de tallas: mostrar el stock en tiempo real dentro del chat.",
];

include 'includes/header.php';
?>

<section class="container my-5">
    <h1 class="h3 mb-1">Reporte del mes — Chatbot de atención al cliente</h1>
    <p class="text-secondary mb-4"><?= date('F Y') ?></p>

    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="card gc-card p-4 text-center h-100">
                <i class="bi bi-people fs-2 text-danger mb-2"></i>
                <h2 class="display-6 fw-bold mb-0"><?= number_format($totalAtendidos, 0, ',', '.') ?></h2>
                <p class="text-secondary mb-0">Personas atendidas</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card gc-card p-4 text-center h-100">
                <i class="bi bi-star fs-2 text-warning mb-2"></i>
                <h2 class="display-6 fw-bold mb-0"><?= $promedioMes ?>/5</h2>
                <p class="text-secondary mb-0">
                    Calificación promedio
                    <?php if ($promedioMes >= $promedioMesAnterior): ?>
                        <span class="text-success small"><i class="bi bi-arrow-up-short"></i> vs <?= $promedioMesAnterior ?> mes anterior</span>
                    <?php else: ?>
                        <span class="text-danger small"><i class="bi bi-arrow-down-short"></i> vs <?= $promedioMesAnterior ?> mes anterior</span>
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card gc-card p-4 text-center h-100">
                <i class="bi bi-chat-dots fs-2 text-primary mb-2"></i>
                <h2 class="display-6 fw-bold mb-0"><?= array_key_first($porTipo) ?></h2>
                <p class="text-secondary mb-0">Tipo de consulta más frecuente</p>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="card gc-card p-4 h-100">
                <h3 class="h6 mb-3">1. Personas atendidas por tipo de consulta</h3>
                <canvas id="graficoTipos"></canvas>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card gc-card p-4 h-100">
                <h3 class="h6 mb-3">2. Clasificación de la atención según los clientes</h3>
                <canvas id="graficoCalificaciones"></canvas>
            </div>
        </div>
    </div>

    <div class="card gc-card p-4">
        <h3 class="h6 mb-3">3. Sugerencias para la administración</h3>
        <ul class="mb-0">
            <?php foreach ($sugerencias as $s): ?>
                <li class="mb-2"><?= htmlspecialchars($s) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
</section>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.4/dist/chart.umd.min.js"></script>
<script>
    new Chart(document.getElementById('graficoTipos'), {
        type: 'bar',
        data: {
            labels: <?= json_encode(array_keys($porTipo)) ?>,
            datasets: [{
                label: 'Consultas',
                data: <?= json_encode(array_values($porTipo)) ?>,
                backgroundColor: '#c0392b'
            }]
        },
        options: { plugins: { legend: { display: false } } }
    });

    new Chart(document.getElementById('graficoCalificaciones'), {
        type: 'doughnut',
        data: {
            labels: <?= json_encode(array_keys($calificaciones)) ?>,
            datasets: [{
                data: <?= json_encode(array_values($calificaciones)) ?>,
                backgroundColor: ['#27ae60', '#2ecc71', '#f1c40f', '#e74c3c']
            }]
        }
    });
</script>

<?php include 'includes/footer.php'; ?>
