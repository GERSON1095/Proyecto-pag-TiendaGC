<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';

// El carrito es exclusivo para clientes registrados
if (empty($_SESSION['cliente_id']) && empty($_SESSION['usuario_id'])) {
    header('Location: login_cliente.php');
    exit;
}

if (!isset($_SESSION['carrito'])) {
    $_SESSION['carrito'] = []; // formato: [producto_id => cantidad]
}

$accion = $_POST['accion'] ?? $_GET['accion'] ?? null;
$mensajeError = '';
$mensajeOk = '';

/**
 * Obtiene el stock disponible de un producto.
 */
function obtenerStock(PDO $pdo, int $id): int
{
    $stmt = $pdo->prepare("SELECT stock FROM productos WHERE id = ? AND estado = 'activo'");
    $stmt->execute([$id]);
    $stock = $stmt->fetchColumn();
    return $stock === false ? 0 : (int) $stock;
}

// --- Agregar producto (validando stock) ---
if ($accion === 'agregar') {
    $id = (int) ($_POST['id'] ?? $_GET['id'] ?? 0);
    if ($id > 0 && $pdo) {
        $stock = obtenerStock($pdo, $id);
        $cantidadActual = (int) ($_SESSION['carrito'][$id] ?? 0);

        if ($stock <= 0) {
            $_SESSION['flash_error'] = 'Este producto no tiene existencias disponibles.';
        } elseif ($cantidadActual + 1 > $stock) {
            $_SESSION['flash_error'] = "Solo hay $stock unidad(es) disponibles de este producto.";
        } else {
            $_SESSION['carrito'][$id] = $cantidadActual + 1;
            $_SESSION['flash_ok'] = 'Producto agregado al carrito.';
        }
    }
    header('Location: carrito.php');
    exit;
}

// --- Actualizar cantidades (validando stock) ---
if ($accion === 'actualizar' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $erroresStock = [];
    foreach ($_POST['cantidad'] ?? [] as $idProducto => $cantidad) {
        $idProducto = (int) $idProducto;
        $cantidad = (int) $cantidad;

        if ($cantidad <= 0) {
            unset($_SESSION['carrito'][$idProducto]);
            continue;
        }

        if ($pdo) {
            $stock = obtenerStock($pdo, $idProducto);
            if ($cantidad > $stock) {
                $_SESSION['carrito'][$idProducto] = $stock; // ajusta al máximo permitido
                $erroresStock[] = "El producto #$idProducto solo tiene $stock unidad(es). Se ajustó la cantidad.";
            } else {
                $_SESSION['carrito'][$idProducto] = $cantidad;
            }
        } else {
            $_SESSION['carrito'][$idProducto] = $cantidad;
        }
    }
    if ($erroresStock) {
        $_SESSION['flash_error'] = implode(' ', $erroresStock);
    } else {
        $_SESSION['flash_ok'] = 'Cantidades actualizadas.';
    }
    header('Location: carrito.php');
    exit;
}

// --- Ir al checkout: primero guarda cantidades y valida stock ---
if ($accion === 'ir_checkout' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $erroresStock = [];

    foreach ($_POST['cantidad'] ?? [] as $idProducto => $cantidad) {
        $idProducto = (int) $idProducto;
        $cantidad = (int) $cantidad;

        if ($cantidad <= 0) {
            unset($_SESSION['carrito'][$idProducto]);
            continue;
        }

        if ($pdo) {
            $stock = obtenerStock($pdo, $idProducto);
            if ($stock <= 0) {
                unset($_SESSION['carrito'][$idProducto]);
                $erroresStock[] = "Un producto ya no tiene existencias y se quitó del carrito.";
            } elseif ($cantidad > $stock) {
                $_SESSION['carrito'][$idProducto] = $stock;
                $erroresStock[] = "Solo hay $stock unidad(es) de un producto. Se ajustó la cantidad.";
            } else {
                $_SESSION['carrito'][$idProducto] = $cantidad;
            }
        } else {
            $_SESSION['carrito'][$idProducto] = $cantidad;
        }
    }

    if (!empty($erroresStock)) {
        $_SESSION['flash_error'] = implode(' ', $erroresStock);
        header('Location: carrito.php');
        exit;
    }

    if (empty($_SESSION['carrito'])) {
        $_SESSION['flash_error'] = 'Tu carrito está vacío.';
        header('Location: carrito.php');
        exit;
    }

    header('Location: checkout.php');
    exit;
}

// --- Eliminar un producto ---
if ($accion === 'eliminar') {
    $id = (int) ($_GET['id'] ?? 0);
    unset($_SESSION['carrito'][$id]);
    header('Location: carrito.php');
    exit;
}

// --- Vaciar el carrito ---
if ($accion === 'vaciar') {
    $_SESSION['carrito'] = [];
    header('Location: carrito.php');
    exit;
}

// Mensajes flash
if (!empty($_SESSION['flash_error'])) {
    $mensajeError = $_SESSION['flash_error'];
    unset($_SESSION['flash_error']);
}
if (!empty($_SESSION['flash_ok'])) {
    $mensajeOk = $_SESSION['flash_ok'];
    unset($_SESSION['flash_ok']);
}

// --- Armar el resumen para mostrar ---
$itemsCarrito = [];
$total = 0;
$hayStockBajo = false;

if ($pdo && !empty($_SESSION['carrito'])) {
    $ids = array_keys($_SESSION['carrito']);
    $marcadores = implode(',', array_fill(0, count($ids), '?'));
    $stmt = $pdo->prepare("
        SELECT id, nombre, marca, precio, descuento, imagen, stock, stock_minimo
        FROM productos
        WHERE id IN ($marcadores)
    ");
    $stmt->execute($ids);
    $productosCarrito = $stmt->fetchAll();

    foreach ($productosCarrito as $p) {
        $cantidad = (int) $_SESSION['carrito'][$p['id']];
        $stock = (int) $p['stock'];
        $stockMinimo = (int) ($p['stock_minimo'] ?? 5);

        // Si por alguna razón la cantidad supera el stock, la recortamos
        if ($cantidad > $stock) {
            $cantidad = max(0, $stock);
            if ($cantidad === 0) {
                unset($_SESSION['carrito'][$p['id']]);
                continue;
            }
            $_SESSION['carrito'][$p['id']] = $cantidad;
        }

        $precioFinal = $p['precio'] * (1 - ($p['descuento'] ?? 0) / 100);
        $subtotal = $precioFinal * $cantidad;
        $total += $subtotal;

        $stockBajo = ($stock <= $stockMinimo);
        if ($stockBajo) {
            $hayStockBajo = true;
        }

        $itemsCarrito[] = [
            'id' => $p['id'],
            'nombre' => $p['nombre'],
            'marca' => $p['marca'],
            'imagen' => $p['imagen'],
            'cantidad' => $cantidad,
            'precio_final' => $precioFinal,
            'subtotal' => $subtotal,
            'stock' => $stock,
            'stock_minimo' => $stockMinimo,
            'stock_bajo' => $stockBajo,
        ];
    }
}

include 'includes/header.php';
?>

<section class="container my-5">
    <h1 class="h4 mb-4"><?= t('tu_carrito') ?></h1>

    <?php if ($mensajeError): ?>
        <div class="alert alert-danger"><?= htmlspecialchars($mensajeError) ?></div>
    <?php endif; ?>
    <?php if ($mensajeOk): ?>
        <div class="alert alert-success"><?= htmlspecialchars($mensajeOk) ?></div>
    <?php endif; ?>
    <?php if ($hayStockBajo): ?>
        <div class="alert alert-warning">
            <?= t('alerta_stock_bajo') ?>
        </div>
    <?php endif; ?>

    <?php if (empty($itemsCarrito)): ?>
        <div class="alert alert-info">
            <?= t('carrito_vacio') ?> <a href="index.php"><?= t('explora_catalogo') ?></a>
        </div>
    <?php else: ?>
        <form action="carrito.php" method="post">

            <div class="table-responsive bg-white rounded shadow-sm mb-4">
                <table class="table align-middle mb-0">
                    <thead class="table-dark">
                        <tr>
                            <th></th>
                            <th><?= t('producto') ?></th>
                            <th><?= t('precio') ?></th>
                            <th style="width:110px;"><?= t('cantidad') ?></th>
                            <th><?= t('disponible') ?></th>
                            <th><?= t('subtotal') ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($itemsCarrito as $item): ?>
                            <tr class="<?= $item['stock_bajo'] ? 'table-warning' : '' ?>">
                                <td style="width:60px;">
                                    <?php if (!empty($item['imagen'])): ?>
                                        <img src="<?= htmlspecialchars($item['imagen']) ?>" alt="" style="width:48px;height:48px;object-fit:cover;border-radius:8px;">
                                    <?php else: ?>
                                        <div class="bg-light d-flex align-items-center justify-content-center" style="width:48px;height:48px;border-radius:8px;">
                                            <i class="bi bi-image text-secondary"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="fw-bold"><?= htmlspecialchars($item['nombre']) ?></div>
                                    <div class="small text-secondary"><?= htmlspecialchars($item['marca']) ?></div>
                                    <?php if ($item['stock_bajo']): ?>
                                        <span class="badge bg-warning text-dark"><?= t('inventario_bajo') ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>$<?= number_format($item['precio_final'], 0, ',', '.') ?></td>
                                <td>
                                    <input type="number"
                                           name="cantidad[<?= (int) $item['id'] ?>]"
                                           value="<?= (int) $item['cantidad'] ?>"
                                           min="0"
                                           max="<?= (int) $item['stock'] ?>"
                                           class="form-control form-control-sm">
                                </td>
                                <td class="small"><?= (int) $item['stock'] ?></td>
                                <td class="fw-bold">$<?= number_format($item['subtotal'], 0, ',', '.') ?></td>
                                <td>
                                    <a href="carrito.php?accion=eliminar&id=<?= (int) $item['id'] ?>" class="btn btn-sm btn-outline-danger">
                                        <i class="bi bi-trash"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div class="d-flex gap-2">
                    <button type="submit" name="accion" value="actualizar" class="btn btn-outline-dark btn-sm">
                        <?= t('actualizar_cant') ?>
                    </button>
                    <a href="carrito.php?accion=vaciar" class="btn btn-outline-danger btn-sm"
                       onclick="return confirm('<?= t('confirmar_vaciar') ?>');"><?= t('vaciar_carrito') ?></a>
                </div>
                <div class="text-end">
                    <div class="h5 mb-2"><?= t('total') ?>: $<?= number_format($total, 0, ',', '.') ?></div>
                    <button type="submit" name="accion" value="ir_checkout" class="btn btn-danger px-4">
                        <?= t('proceder_pago') ?>
                    </button>
                </div>
            </div>
        </form>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
