<?php
require_once 'includes/db.php';

/**
 * Productos de ejemplo en memoria (fallback si no hay BD).
 * Con la BD conectada se reemplazan por la consulta real.
 */
$productos = [
    ['nombre' => 'Hoodie Essential', 'marca' => 'Nike', 'categoria' => 'Hoodies', 'precio' => 189900],
    ['nombre' => 'Hoodie Trefoil', 'marca' => 'Adidas', 'categoria' => 'Hoodies', 'precio' => 175900],
    ['nombre' => 'Sneaker Air Max', 'marca' => 'Nike', 'categoria' => 'Sneakers', 'precio' => 429900],
    ['nombre' => 'Sneaker Ultraboost', 'marca' => 'Adidas', 'categoria' => 'Sneakers', 'precio' => 599900],
    ['nombre' => 'Sneaker RS-X', 'marca' => 'Puma', 'categoria' => 'Sneakers', 'precio' => 349900],
    ['nombre' => 'Gorra Snapback', 'marca' => 'Nike', 'categoria' => 'Gorras', 'precio' => 79900],
    ['nombre' => 'Gorra Trefoil', 'marca' => 'Adidas', 'categoria' => 'Gorras', 'precio' => 74900],
    ['nombre' => 'Camisa Deportiva Dri-FIT', 'marca' => 'Nike', 'categoria' => 'Camisas', 'precio' => 129900],
    ['nombre' => 'Camisa Puma Active', 'marca' => 'Puma', 'categoria' => 'Camisas', 'precio' => 109900],
    ['nombre' => 'Pantalón Jogger Tiro', 'marca' => 'Adidas', 'categoria' => 'Pantalones', 'precio' => 159900],
    ['nombre' => 'Pantalón Jogger Sportswear', 'marca' => 'Nike', 'categoria' => 'Pantalones', 'precio' => 169900],
    ['nombre' => 'Pantalón Puma Fit', 'marca' => 'Puma', 'categoria' => 'Pantalones', 'precio' => 149900],
];

if ($pdo) {
    try {
        $productos = $pdo->query("
            SELECT p.id, p.nombre, p.marca, p.precio, p.descuento, p.tallas, p.colores, p.imagen, p.stock,
                   c.nombre AS categoria
            FROM productos p
            LEFT JOIN categorias c ON c.id = p.categoria_id
            WHERE p.estado = 'activo'
            ORDER BY p.id DESC
        ")->fetchAll();
    } catch (PDOException $e) {
        // Si la tabla aún no existe, seguimos usando el arreglo de ejemplo.
    }
}

$categorias = array_values(array_unique(array_filter(array_column($productos, 'categoria'))));
$marcas = array_values(array_unique(array_filter(array_column($productos, 'marca'))));

include 'includes/header.php';
?>

<header class="gc-hero text-center text-white d-flex align-items-center justify-content-center">
    <div class="container">
        <h1 class="display-5 fw-bold">Ropa original</h1>
        <p class="lead mb-4">Nike, Adidas, Puma y más</p>

        <form class="gc-search mx-auto" action="index.php" method="get">
            <div class="input-group input-group-lg">
                <span class="input-group-text bg-white border-0"><i class="bi bi-search"></i></span>
                <input type="text" id="buscador" name="q" class="form-control border-0"
                       placeholder="Busca hoodies, sneakers, gorras..."
                       value="<?= htmlspecialchars($_GET['q'] ?? '') ?>">
                <button class="btn btn-danger px-4" type="submit">Buscar</button>
            </div>
        </form>
    </div>
</header>

<section class="container my-5">

    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
        <h2 class="h4 mb-0">Catálogo</h2>

        <div class="dropdown">
            <button class="btn btn-outline-dark dropdown-toggle" type="button"
                    id="btnFiltros" data-bs-toggle="dropdown" data-bs-auto-close="outside">
                <i class="bi bi-funnel"></i> Filtros
            </button>
            <div class="dropdown-menu p-3 gc-filtros" aria-labelledby="btnFiltros">
                <div class="mb-3">
                    <label class="form-label fw-bold small">Categoría</label>
                    <select id="filtroCategoria" class="form-select form-select-sm">
                        <option value="">Todas</option>
                        <?php foreach ($categorias as $cat): ?>
                            <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars($cat) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label fw-bold small">Marca</label>
                    <select id="filtroMarca" class="form-select form-select-sm">
                        <option value="">Todas</option>
                        <?php foreach ($marcas as $m): ?>
                            <option value="<?= htmlspecialchars($m) ?>"><?= htmlspecialchars($m) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label fw-bold small">Precio máximo: <span id="valorPrecio">$600.000</span></label>
                    <input type="range" class="form-range" id="filtroPrecio" min="50000" max="600000" step="10000" value="600000">
                </div>
                <button id="btnLimpiarFiltros" class="btn btn-sm btn-link px-0">Limpiar filtros</button>
            </div>
        </div>
    </div>

    <div class="row g-4" id="grid-productos">
        <?php foreach ($productos as $p): ?>
            <div class="col-6 col-md-4 col-lg-3 producto-item"
                 data-categoria="<?= htmlspecialchars($p['categoria'] ?? '') ?>"
                 data-marca="<?= htmlspecialchars($p['marca'] ?? '') ?>"
                 data-precio="<?= (int) $p['precio'] ?>"
                 data-nombre="<?= htmlspecialchars(mb_strtolower($p['nombre'])) ?>">
                <div class="card gc-card h-100">
                    <div class="gc-card-img d-flex align-items-center justify-content-center">
                        <?php if (!empty($p['imagen'])): ?>
                            <img src="<?= htmlspecialchars($p['imagen']) ?>" alt="<?= htmlspecialchars($p['nombre']) ?>"
                                 class="w-100 h-100" style="object-fit: cover; border-radius: 14px 14px 0 0;">
                        <?php else: ?>
                            <i class="bi bi-bag-heart fs-1 text-secondary"></i>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <span class="badge bg-dark mb-2"><?= htmlspecialchars($p['marca']) ?></span>
                        <?php if (!empty($p['descuento'])): ?>
                            <span class="badge bg-danger mb-2">-<?= (int) $p['descuento'] ?>%</span>
                        <?php endif; ?>
                        <h3 class="h6 mb-1"><?= htmlspecialchars($p['nombre']) ?></h3>
                        <p class="text-secondary small mb-1"><?= htmlspecialchars($p['categoria'] ?? '') ?></p>
                        <?php if (!empty($p['tallas'])): ?>
                            <p class="text-secondary small mb-2">Tallas: <?= htmlspecialchars($p['tallas']) ?></p>
                        <?php endif; ?>
                        <?php if (!empty($p['descuento'])):
                            $precioFinal = $p['precio'] * (1 - $p['descuento'] / 100); ?>
                            <p class="mb-3">
                                <span class="text-decoration-line-through text-secondary small">$<?= number_format($p['precio'], 0, ',', '.') ?></span>
                                <span class="fw-bold text-danger">$<?= number_format($precioFinal, 0, ',', '.') ?></span>
                            </p>
                        <?php else: ?>
                            <p class="fw-bold mb-3">$<?= number_format($p['precio'], 0, ',', '.') ?></p>
                        <?php endif; ?>
                        <?php if (isset($p['id'])): ?>
                            <form action="carrito.php" method="post">
                                <input type="hidden" name="accion" value="agregar">
                                <input type="hidden" name="id" value="<?= (int) $p['id'] ?>">
                                <button type="submit" class="btn btn-sm btn-dark w-100">Agregar al carrito</button>
                            </form>
                        <?php else: ?>
                            <button class="btn btn-sm btn-dark w-100" disabled title="Conecta la base de datos para poder comprar">Agregar al carrito</button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>

    <p id="sinResultados" class="text-center text-secondary mt-4 d-none">
        No encontramos productos con esos filtros.
    </p>
</section>

<?php include 'includes/footer.php'; ?>