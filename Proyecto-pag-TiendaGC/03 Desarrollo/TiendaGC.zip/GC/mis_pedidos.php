<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';

if (empty($_SESSION['cliente_id'])) {
    header('Location: login_cliente.php');
    exit;
}

$pedidos = [];
if ($pdo) {
    $stmt = $pdo->prepare("SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY creado_en DESC");
    $stmt->execute([$_SESSION['usuario_id'] ?? $_SESSION['cliente_id']]);
    $pedidos = $stmt->fetchAll();
}

function colorEstado(string $estado): string
{
    return match ($estado) {
        'Pendiente' => 'bg-warning text-dark',
        'En proceso' => 'bg-info text-dark',
        'Enviado' => 'bg-primary',
        'Entregado' => 'bg-success',
        'Cancelado' => 'bg-danger',
        default => 'bg-secondary',
    };
}

function traducirEstado(string $estado): string
{
    $mapa = [
        'Pendiente'  => 'estado_pendiente',
        'En proceso' => 'estado_en_proceso',
        'Enviado'    => 'estado_enviado',
        'Entregado'  => 'estado_entregado',
        'Cancelado'  => 'estado_cancelado',
    ];
    return t($mapa[$estado] ?? $estado);
}

include 'includes/header.php';
?>

<section class="container my-5">
    <h1 class="h4 mb-4"><?= t('mis_pedidos_titulo') ?></h1>

    <?php if (empty($pedidos)): ?>
        <div class="alert alert-info"><?= t('sin_pedidos') ?> <a href="index.php"><?= t('ir_catalogo') ?></a></div>
    <?php else: ?>
        <div class="table-responsive bg-white rounded shadow-sm">
            <table class="table align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th><?= t('pedido_num') ?></th>
                        <th><?= t('referencia') ?></th>
                        <th><?= t('fecha') ?></th>
                        <th><?= t('total') ?></th>
                        <th><?= t('pago') ?></th>
                        <th><?= t('estado') ?></th>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($pedidos as $p): ?>
                        <tr>
                            <td>#<?= (int) $p['id'] ?></td>
                            <td><code><?= htmlspecialchars($p['numero_referencia']) ?></code></td>
                            <td><?= date('d/m/Y H:i', strtotime($p['creado_en'])) ?></td>
                            <td>$<?= number_format($p['total'], 0, ',', '.') ?></td>
                            <td><?= htmlspecialchars($p['metodo_pago']) ?></td>
                            <td>
                                <span class="badge <?= colorEstado($p['estado']) ?>">
                                    <?= htmlspecialchars(traducirEstado($p['estado'])) ?>
                                </span>
                            </td>
                            <td>
                                <a href="pedido_confirmado.php?id=<?= (int) $p['id'] ?>" class="btn btn-sm btn-outline-dark">
                                    <?= t('ver') ?>
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
