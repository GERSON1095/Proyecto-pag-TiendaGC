<?php include 'includes/header.php'; ?>

<section class="container my-5">
    <h1 class="h3 mb-2">Política de Tratamiento de Datos Personales</h1>
    <p class="text-secondary mb-4">
        GC clasifica la información que recolecta de sus clientes según su nivel de sensibilidad,
        de acuerdo con la Ley 1581 de 2012 y el Decreto 1377 de 2013 de Colombia.
        Esto define qué controles de seguridad y qué nivel de acceso aplica a cada dato.
    </p>

    <div class="table-responsive bg-white rounded shadow-sm mb-4">
        <table class="table align-middle mb-0">
            <thead class="table-dark">
                <tr>
                    <th>Nivel</th>
                    <th>Ejemplos en GC</th>
                    <th>Cómo lo tratamos</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td><span class="badge bg-secondary">Pública</span></td>
                    <td>Catálogo de productos, precios, promociones, esta misma política</td>
                    <td>Acceso libre, sin restricciones ni consentimiento requerido.</td>
                </tr>
                <tr>
                    <td><span class="badge bg-primary">Semiprivada</span></td>
                    <td>Historial de conversación con el chatbot, productos consultados</td>
                    <td>Uso interno para mejorar el servicio. Acceso restringido al equipo de GC.</td>
                </tr>
                <tr>
                    <td><span class="badge bg-warning text-dark">Privada</span></td>
                    <td>Nombre, correo, teléfono, dirección de envío</td>
                    <td>
                        Requiere tu autorización expresa (Habeas Data) al registrarte.
                        El teléfono y la dirección se guardan <strong>cifrados</strong> en nuestra base de datos.
                    </td>
                </tr>
                <tr>
                    <td><span class="badge bg-danger">Sensible</span></td>
                    <td>Contraseña de tu cuenta, datos de pago</td>
                    <td>
                        Tu contraseña nunca se guarda como texto plano (se almacena con hash irreversible).
                        Los datos de tarjeta no se almacenan en nuestros servidores: se procesan a través
                        de una pasarela de pago certificada.
                    </td>
                </tr>
            </tbody>
        </table>
    </div>

    <h2 class="h5">Tus derechos como titular de los datos</h2>
    <ul>
        <li>Conocer, actualizar y rectificar tus datos personales.</li>
        <li>Solicitar prueba de la autorización otorgada.</li>
        <li>Revocar la autorización y/o solicitar la eliminación de tus datos, cuando la ley lo permita.</li>
        <li>Presentar quejas ante la Superintendencia de Industria y Comercio por infracciones a la ley de protección de datos.</li>
    </ul>

    <p class="text-secondary small mt-4">
        Para ejercer estos derechos, o si tienes dudas sobre el tratamiento de tus datos, puedes
        escribirle a nuestro chatbot o contactar al equipo de GC directamente.
    </p>
</section>

<?php include 'includes/footer.php'; ?>