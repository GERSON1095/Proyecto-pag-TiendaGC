-- ===========================================================
-- GC Tienda - Esquema v2
-- Corrige lo exigido por la actividad "Transformar una tienda
-- web en un sistema de información empresarial básico":
--
--   1. Unifica clientes + admin en una sola tabla USUARIOS con rol
--      (Cliente / Administrador) en vez de una clave fija en config.php.
--   2. Crea la tabla CATEGORIA como entidad propia (antes era un
--      simple VARCHAR en productos).
--   3. Agrega a PRODUCTO los campos que pedía el enunciado y que
--      faltaban: descripcion, estado y umbral de inventario mínimo
--      (stock_minimo) para la alerta de existencias bajas.
--   4. PEDIDO y DETALLE_PEDIDO ahora apuntan a usuario_id en vez de
--      cliente_id, para que un único modelo de usuarios sirva tanto
--      a clientes como (a futuro) a reportes de administrador.
--
-- Este script RECREA la base de datos desde cero. Es la forma más
-- simple de aplicar el cambio en un entorno de desarrollo (XAMPP).
-- Si ya tienes datos reales de clientes/pedidos que NO puedes perder,
-- usa en su lugar el script de migración (gc_migracion_v1_a_v2.sql)
-- que actualiza la estructura conservando los datos existentes.
-- ===========================================================

DROP DATABASE IF EXISTS gc_tienda;
CREATE DATABASE gc_tienda CHARACTER SET utf8mb4;
USE gc_tienda;

-- ===========================================================
-- USUARIO
-- Reemplaza la tabla "clientes" + la clave fija de admin.
-- rol define el control de acceso: 'cliente' o 'administrador'.
-- ===========================================================
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,                   -- PRIVADO
    correo VARCHAR(150) NOT NULL UNIQUE,             -- PRIVADO
    telefono_cifrado VARBINARY(255) DEFAULT NULL,    -- PRIVADO (cifrado en la app)
    direccion_cifrada VARBINARY(255) DEFAULT NULL,   -- PRIVADO (cifrado en la app)
    password_hash VARCHAR(255) NOT NULL,             -- SENSIBLE (hash, nunca texto plano)
    rol ENUM('cliente', 'administrador') NOT NULL DEFAULT 'cliente',
    acepto_tratamiento_datos TINYINT(1) DEFAULT 0,   -- consentimiento (Habeas Data)
    fecha_aceptacion DATETIME DEFAULT NULL,
    activo TINYINT(1) DEFAULT 1,                     -- permite deshabilitar una cuenta sin borrarla
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ===========================================================
-- CATEGORIA
-- Antes "categoria" era un VARCHAR suelto dentro de productos.
-- ===========================================================
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO categorias (nombre) VALUES
('Hoodies'), ('Sneakers'), ('Gorras'), ('Camisas'), ('Pantalones');

-- ===========================================================
-- PRODUCTO
-- Se conservan marca/tallas/colores/descuento (identidad propia
-- del proyecto). Se agregan: descripcion, estado y stock_minimo
-- (para la alerta de inventario bajo que pide el punto 2.3 y el
-- panel administrativo del punto 4).
-- ===========================================================
CREATE TABLE productos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    marca VARCHAR(50) NOT NULL,
    categoria_id INT NOT NULL,
    descripcion TEXT DEFAULT NULL,
    tallas VARCHAR(150) DEFAULT NULL COMMENT 'Separadas por coma, ej: S,M,L,XL',
    colores VARCHAR(150) DEFAULT NULL COMMENT 'Separados por coma, ej: Negro,Blanco',
    precio DECIMAL(10,2) NOT NULL,
    descuento TINYINT DEFAULT 0 COMMENT 'Porcentaje de descuento (0-100)',
    stock INT NOT NULL DEFAULT 10,
    stock_minimo INT NOT NULL DEFAULT 5 COMMENT 'Umbral para la alerta de inventario bajo',
    imagen VARCHAR(255) DEFAULT NULL,
    estado ENUM('activo', 'inactivo') NOT NULL DEFAULT 'activo',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

INSERT INTO productos (nombre, marca, categoria_id, descripcion, tallas, colores, precio, descuento, stock, stock_minimo, imagen) VALUES
('Hoodie Essential', 'Nike', (SELECT id FROM categorias WHERE nombre = 'Hoodies'), 'Hoodie unisex de algodón perchado, ideal para uso diario.', 'S,M,L,XL', 'Negro,Gris', 189900, 0, 15, 5, NULL),
('Hoodie Trefoil', 'Adidas', (SELECT id FROM categorias WHERE nombre = 'Hoodies'), 'Hoodie con logo Trefoil bordado y bolsillo canguro.', 'M,L,XL', 'Negro,Blanco', 175900, 15, 12, 5, NULL),
('Sneaker Air Max', 'Nike', (SELECT id FROM categorias WHERE nombre = 'Sneakers'), 'Sneaker con amortiguación Air visible, uso urbano y deportivo.', '38,39,40,41,42', 'Blanco,Negro', 429900, 0, 8, 4, NULL),
('Sneaker Ultraboost', 'Adidas', (SELECT id FROM categorias WHERE nombre = 'Sneakers'), 'Sneaker de running con entresuela Boost para máximo retorno de energía.', '39,40,41,42,43', 'Negro', 599900, 0, 6, 4, NULL),
('Sneaker RS-X', 'Puma', (SELECT id FROM categorias WHERE nombre = 'Sneakers'), 'Sneaker chunky retro con mezcla de materiales.', '40,41,42,43', 'Blanco,Azul', 349900, 10, 10, 4, NULL),
('Gorra Snapback', 'Nike', (SELECT id FROM categorias WHERE nombre = 'Gorras'), 'Gorra ajustable snapback, estructura clásica.', 'Única', 'Negro,Rojo', 79900, 20, 20, 6, NULL),
('Gorra Trefoil', 'Adidas', (SELECT id FROM categorias WHERE nombre = 'Gorras'), 'Gorra con bordado Trefoil y visera curva.', 'Única', 'Blanco,Negro', 74900, 0, 18, 6, NULL),
('Camisa Deportiva Dri-FIT', 'Nike', (SELECT id FROM categorias WHERE nombre = 'Camisas'), 'Camiseta deportiva con tecnología Dri-FIT que absorbe el sudor.', 'S,M,L', 'Negro,Gris,Azul', 129900, 0, 14, 5, NULL),
('Camisa Puma Active', 'Puma', (SELECT id FROM categorias WHERE nombre = 'Camisas'), 'Camiseta básica de algodón para entrenamiento o uso casual.', 'S,M,L,XL', 'Blanco,Negro', 109900, 10, 11, 5, NULL),
('Pantalón Jogger Tiro', 'Adidas', (SELECT id FROM categorias WHERE nombre = 'Pantalones'), 'Jogger deportivo con puños ajustados y bolsillos con cierre.', 'S,M,L,XL', 'Negro', 159900, 0, 9, 4, NULL),
('Pantalón Jogger Sportswear', 'Nike', (SELECT id FROM categorias WHERE nombre = 'Pantalones'), 'Jogger de algodón suave, corte cómodo para el día a día.', 'M,L,XL', 'Gris,Negro', 169900, 0, 7, 4, NULL),
('Pantalón Puma Fit', 'Puma', (SELECT id FROM categorias WHERE nombre = 'Pantalones'), 'Pantalón deportivo ajustado, ideal para entrenar.', 'S,M,L', 'Negro,Azul', 149900, 0, 13, 4, NULL);

-- ===========================================================
-- PEDIDO
-- Ahora referencia usuario_id (antes cliente_id) para alinearse
-- con el modelo de USUARIO unificado.
-- ===========================================================
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    numero_referencia VARCHAR(20) NOT NULL UNIQUE,     -- ej: GC-7K2P9XAB
    direccion_envio_cifrada VARBINARY(500) NOT NULL,   -- PRIVADO (cifrado en la app)
    metodo_pago VARCHAR(30) NOT NULL,
    referencia_pago VARCHAR(50) DEFAULT NULL,          -- ej: "Tarjeta terminada en 1234"
    total DECIMAL(10,2) NOT NULL,
    estado ENUM('Pendiente','En proceso','Enviado','Entregado','Cancelado') DEFAULT 'Pendiente',
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- ===========================================================
-- DETALLE_PEDIDO
-- ===========================================================
CREATE TABLE detalle_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT NOT NULL,
    producto_id INT DEFAULT NULL,
    nombre_producto VARCHAR(100) NOT NULL,
    precio_unitario DECIMAL(10,2) NOT NULL,
    cantidad INT NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (producto_id) REFERENCES productos(id)
);

-- ===========================================================
-- Tabla para el reporte mensual del chatbot (se conserva igual,
-- solo se renombra cliente_id -> usuario_id por consistencia).
-- ===========================================================
CREATE TABLE atenciones_chatbot (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT DEFAULT NULL,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    tipo_consulta ENUM('producto','pedido','pago','devolucion','otro') DEFAULT 'otro',
    calificacion ENUM('Excelente','Buena','Regular','Mala') DEFAULT NULL,
    comentario TEXT DEFAULT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- ===========================================================
-- Cuenta de administrador inicial.
-- No se incluye aquí un password_hash de ejemplo (sería el mismo
-- hash para todos los que usen este script, lo cual es inseguro).
-- Pasos para crear tu propio admin:
--   1. Regístrate normalmente desde registro.php como si fueras cliente.
--   2. Ejecuta este UPDATE reemplazando el correo:
--
--      UPDATE usuarios SET rol = 'administrador' WHERE correo = 'tu_correo@ejemplo.com';
--
-- Así el hash de la contraseña lo genera PHP con password_hash(),
-- tal como exige el punto 2.1 del reto (nunca contraseñas en texto plano).
-- ===========================================================