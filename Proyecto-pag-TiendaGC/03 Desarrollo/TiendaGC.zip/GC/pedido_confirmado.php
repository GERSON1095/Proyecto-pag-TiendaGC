<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';
require_once 'includes/cifrado.php';

if (empty($_SESSION['cliente_id'])) {
    header('Location: login_cliente.php');
    exit;
}

$id = (int) ($_GET['id'] ?? 0);

$pedido = null;
$detalle = [];

if ($pdo && $id > 0) {
    $stmt = $pdo->prepare("SELECT * FROM pedidos WHERE id = ? AND usuario_id = ?");
    $stmt->execute([$id, $_SESSION['usuario_id'] ?? $_SESSION['cliente_id']]);
    $pedido = $stmt->fetch();

    if ($pedido) {
        $stmt = $pdo->prepare("SELECT * FROM detalle_pedido WHERE pedido_id = ?");
        $stmt->execute([$id]);
        $detalle = $stmt->fetchAll();
    }
}

if (!$pedido) {
    header('Location: index.php');
    exit;
}

$direccion = descifrar($pedido['direccion_envio_cifrada']);

function traducirEstado(string $estado): string
{
    $mapa = [
        'Pendiente'  => 'estado_pendiente',
        'En proceso' => 'estado_en_proceso',
        'Enviado'    => 'estado_enviado',
        'Entregado'  => 'estado_entregado',
        'Cancelado'  => 'estado_cancelado',
    ];
    return t($mapa[$estado] ?? $estado);
}

include 'includes/header.php';
?>

<section class="container my-5" style="max-width: 640px;">
    <div class="text-center mb-4">
        <i class="bi bi-check-circle-fill text-success" style="font-size: 3rem;"></i>
        <h1 class="h4 mt-2"><?= t('pedido_confirmado') ?></h1>
        <p class="text-secondary mb-1">
            <?= t('pedido_num') ?> #<?= (int) $pedido['id'] ?> — <?= htmlspecialchars(traducirEstado($pedido['estado'])) ?>
        </p>

        <div class="d-inline-block bg-dark text-white px-3 py-2 rounded mt-2">
            <div class="small text-white-50"><?= t('tu_referencia') ?></div>
            <div class="h5 mb-0"><?= htmlspecialchars($pedido['numero_referencia']) ?></div>
        </div>
        <p class="small text-secondary mt-2">
            <?= t('guarda_referencia') ?>
        </p>
    </div>

    <div class="bg-white p-4 rounded shadow-sm mb-4">
        <h2 class="h6"><?= t('resumen') ?></h2>
        <table class="table table-sm">
            <?php foreach ($detalle as $item): ?>
                <tr>
                    <td><?= htmlspecialchars($item['nombre_producto']) ?> × <?= (int) $item['cantidad'] ?></td>
                    <td class="text-end">$<?= number_format($item['subtotal'], 0, ',', '.') ?></td>
                </tr>
            <?php endforeach; ?>
            <tr class="fw-bold">
                <td><?= t('total') ?></td>
                <td class="text-end">$<?= number_format($pedido['total'], 0, ',', '.') ?></td>
            </tr>
        </table>

        <hr>
        <p class="mb-1"><strong><?= t('direccion_envio_label') ?></strong> <?= htmlspecialchars($direccion) ?></p>
        <p class="mb-0"><strong><?= t('pago_label') ?></strong> <?= htmlspecialchars($pedido['referencia_pago'] ?? $pedido['metodo_pago']) ?></p>
    </div>

    <div class="text-center">
        <a href="mis_pedidos.php" class="btn btn-outline-dark me-2"><?= t('ver_mis_pedidos') ?></a>
        <a href="index.php" class="btn btn-danger"><?= t('seguir_comprando') ?></a>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
