document.addEventListener('DOMContentLoaded', () => {
    const LANG = window.GC_LANG || 'es';

    const TXT = {
        es: {
            saludo: '¡Hola! Soy el asistente virtual de GC 👋 Pregúntame por hoodies, sneakers, gorras, camisas, pantalones, envíos, pagos o devoluciones.',
            escribiendo: 'Escribiendo...',
            error: 'Tuve un problema para responder. Intenta de nuevo en un momento.',
            calificarPregunta: '¿Cómo calificarías esta atención?',
            gracias: '¡Gracias por tu calificación! 🙌',
        },
        en: {
            saludo: "Hi! I'm GC's virtual assistant 👋 Ask me about hoodies, sneakers, caps, shirts, pants, shipping, payments or returns.",
            escribiendo: 'Typing...',
            error: 'I had trouble responding. Please try again in a moment.',
            calificarPregunta: 'How would you rate this support?',
            gracias: 'Thanks for your rating! 🙌',
        },
    };
    const T = TXT[LANG] || TXT.es;

    const toggle = document.getElementById('gc-chat-toggle');
    const closeBtn = document.getElementById('gc-chat-close');
    const ventana = document.getElementById('gc-chat-window');
    const form = document.getElementById('gc-chat-form');
    const input = document.getElementById('gc-chat-input');
    const mensajes = document.getElementById('gc-chat-mensajes');
    const rating = document.getElementById('gc-chat-rating');

    if (!toggle) return;

    let saludoMostrado = false;

    function formatoTexto(texto) {
        const contenedor = document.createElement('div');
        contenedor.textContent = texto;
        let html = contenedor.innerHTML;
        html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
        const lineas = html.split('\n');
        let dentroLista = false;
        let resultado = '';
        lineas.forEach((linea) => {
            const esItem = linea.trim().startsWith('- ');
            if (esItem) {
                if (!dentroLista) { resultado += '<ul class="gc-chat-lista">'; dentroLista = true; }
                resultado += `<li>${linea.trim().slice(2)}</li>`;
            } else {
                if (dentroLista) { resultado += '</ul>'; dentroLista = false; }
                resultado += linea + '<br>';
            }
        });
        if (dentroLista) resultado += '</ul>';
        return resultado;
    }

    function agregarMensaje(texto, tipo) {
        const div = document.createElement('div');
        div.className = `gc-chat-msg ${tipo}`;
        if (tipo === 'bot') div.innerHTML = formatoTexto(texto);
        else div.textContent = texto;
        mensajes.appendChild(div);
        mensajes.scrollTop = mensajes.scrollHeight;
        return div;
    }

    toggle.addEventListener('click', () => {
        ventana.classList.toggle('d-none');
        if (!ventana.classList.contains('d-none')) input.focus();
        if (!saludoMostrado) {
            agregarMensaje(T.saludo, 'bot');
            saludoMostrado = true;
        }
    });

    closeBtn.addEventListener('click', () => ventana.classList.add('d-none'));

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const texto = input.value.trim();
        if (!texto) return;
        agregarMensaje(texto, 'user');
        input.value = '';
        const loadingEl = agregarMensaje(T.escribiendo, 'bot');
        try {
            const resp = await fetch('chat.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'mensaje', mensaje: texto }),
            });
            const data = await resp.json();
            loadingEl.remove();
            agregarMensaje(data.respuesta, 'bot');
            rating.classList.remove('d-none');
        } catch (err) {
            loadingEl.remove();
            agregarMensaje(T.error, 'bot');
        }
    });

    rating.addEventListener('click', async (e) => {
        const btn = e.target.closest('button[data-calificacion]');
        if (!btn) return;
        try {
            await fetch('chat.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ accion: 'calificar', calificacion: btn.dataset.calificacion }),
            });
        } catch (err) {}
        rating.classList.add('d-none');
        agregarMensaje(T.gracias, 'bot');
    });
});