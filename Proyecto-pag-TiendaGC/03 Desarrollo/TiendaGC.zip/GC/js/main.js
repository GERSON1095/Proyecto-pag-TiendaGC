document.addEventListener('DOMContentLoaded', () => {
    const buscador = document.getElementById('buscador');
    const filtroCategoria = document.getElementById('filtroCategoria');
    const filtroMarca = document.getElementById('filtroMarca');
    const filtroPrecio = document.getElementById('filtroPrecio');
    const valorPrecio = document.getElementById('valorPrecio');
    const btnLimpiar = document.getElementById('btnLimpiarFiltros');
    const productos = document.querySelectorAll('.producto-item');
    const sinResultados = document.getElementById('sinResultados');

    if (!productos.length) return; // no estamos en index.php

    function aplicarFiltros() {
        const texto = (buscador?.value || '').toLowerCase().trim();
        const categoria = filtroCategoria?.value || '';
        const marca = filtroMarca?.value || '';
        const precioMax = Number(filtroPrecio?.value || 600000);

        if (valorPrecio) valorPrecio.textContent = '$' + precioMax.toLocaleString('es-CO');

        let visibles = 0;

        productos.forEach(item => {
            const coincideTexto = item.dataset.nombre.includes(texto);
            const coincideCategoria = !categoria || item.dataset.categoria === categoria;
            const coincideMarca = !marca || item.dataset.marca === marca;
            const coincidePrecio = Number(item.dataset.precio) <= precioMax;

            const visible = coincideTexto && coincideCategoria && coincideMarca && coincidePrecio;
            item.classList.toggle('d-none', !visible);
            if (visible) visibles++;
        });

        sinResultados?.classList.toggle('d-none', visibles !== 0);
    }

    buscador?.addEventListener('input', aplicarFiltros);
    filtroCategoria?.addEventListener('change', aplicarFiltros);
    filtroMarca?.addEventListener('change', aplicarFiltros);
    filtroPrecio?.addEventListener('input', aplicarFiltros);

    btnLimpiar?.addEventListener('click', () => {
        if (buscador) buscador.value = '';
        if (filtroCategoria) filtroCategoria.value = '';
        if (filtroMarca) filtroMarca.value = '';
        if (filtroPrecio) filtroPrecio.value = 600000;
        aplicarFiltros();
    });
});
