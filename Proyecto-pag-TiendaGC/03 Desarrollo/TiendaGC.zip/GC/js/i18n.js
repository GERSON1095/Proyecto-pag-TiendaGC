document.addEventListener('DOMContentLoaded', () => {
    const lang = window.GC_LANG || 'es';
    if (lang !== 'en') return; // el HTML ya está en español por defecto

    const DICCIONARIO = {
        // Catálogo / general
        'Ropa original': 'Original clothing',
        'Nike, Adidas, Puma y más': 'Nike, Adidas, Puma and more',
        'Buscar': 'Search',
        'Catálogo': 'Catalog',
        'Filtros': 'Filters',
        'Categoría': 'Category',
        'Marca': 'Brand',
        'Todas': 'All',
        'Limpiar filtros': 'Clear filters',
        'No encontramos productos con esos filtros.': 'No products found with those filters.',
        'Agregar al carrito': 'Add to cart',
        'Inicio': 'Home',
        'Reporte del mes': 'Monthly report',
        'Iniciar sesión': 'Log in',
        'Registrarme': 'Sign up',
        'Cerrar sesión': 'Log out',
        'Mis pedidos': 'My orders',
        'Asistente GC': 'GC Assistant',
        'En línea': 'Online',

        // Categorías
        'Hoodies': 'Hoodies',
        'Sneakers': 'Sneakers',
        'Gorras': 'Caps',
        'Camisas': 'Shirts',
        'Pantalones': 'Pants',
        'Tallas:': 'Sizes:',
        'Única': 'One size',

        // Chat
        'Escribe tu pregunta...': 'Type your question...',
        '¿Necesitas ayuda?': 'Need help?',
        '¿Cómo calificarías esta atención?': 'How would you rate this support?',
        'Excelente': 'Excellent',
        'Buena': 'Good',
        'Regular': 'Okay',
        'Mala': 'Poor',

        // Login / Registro
        'Correo electrónico': 'Email',
        'Contraseña': 'Password',
        'Entrar': 'Sign in',
        '¿No tienes cuenta?': "Don't have an account?",
        'Regístrate': 'Sign up',
        'Crear cuenta': 'Create account',
        'Nombre completo': 'Full name',
        'Teléfono': 'Phone',
        '(opcional)': '(optional)',
        'Dirección de envío': 'Shipping address',
        'Autorizo el tratamiento de mis datos personales según la': 'I authorize the processing of my personal data according to the',
        'Política de Tratamiento de Datos': 'Data Privacy Policy',
        '¿Ya tienes cuenta?': 'Already have an account?',
        'Inicia sesión': 'Log in',
        '¡Cuenta creada! Ya puedes': 'Account created! You can now',
        'Correo o contraseña incorrectos.': 'Incorrect email or password.',

        // Carrito
        'Tu carrito': 'Your cart',
        'Tu carrito está vacío.': 'Your cart is empty.',
        'Explora el catálogo': 'Browse the catalog',
        'Producto': 'Product',
        'Precio': 'Price',
        'Cantidad': 'Quantity',
        'Disponible': 'Available',
        'Subtotal': 'Subtotal',
        'Total': 'Total',
        'Actualizar cantidades': 'Update quantities',
        'Vaciar carrito': 'Empty cart',
        '¿Vaciar todo el carrito?': 'Empty the entire cart?',
        'Proceder al pago': 'Proceed to checkout',
        'Inventario bajo': 'Low stock',
        'Algunos productos del carrito tienen inventario bajo. Las unidades disponibles están limitadas.':
            'Some items in your cart have low stock. Available units are limited.',
        'Este producto no tiene existencias disponibles.': 'This product is out of stock.',

        // Checkout
        'Finalizar compra': 'Checkout',
        'Total a pagar:': 'Total to pay:',
        'Dirección': 'Address',
        'Ciudad': 'City',
        'Método de pago': 'Payment method',
        'Selecciona...': 'Select...',
        'Tarjeta de crédito/débito': 'Credit/debit card',
        'PSE': 'PSE',
        'Pago contraentrega': 'Cash on delivery',
        'Número de tarjeta': 'Card number',
        'Vencimiento': 'Expiry',
        'CVV': 'CVV',
        'Confirmar pedido': 'Place order',

        // Pedido confirmado
        '¡Pedido confirmado!': 'Order confirmed!',
        'Tu número de referencia': 'Your reference number',
        'Guarda este número. Con él puedes preguntarle al chatbot por el estado de tu pedido en cualquier momento, sin necesidad de iniciar sesión.':
            'Save this number. You can ask the chatbot about your order status anytime without logging in.',
        'Resumen': 'Summary',
        'Dirección de envío:': 'Shipping address:',
        'Pago:': 'Payment:',
        'Ver mis pedidos': 'View my orders',
        'Seguir comprando': 'Continue shopping',

        // Mis pedidos
        'Todavía no has hecho ningún pedido.': "You haven't placed any orders yet.",
        'Ir al catálogo': 'Go to catalog',
        'Referencia': 'Reference',
        'Fecha': 'Date',
        'Pago': 'Payment',
        'Estado': 'Status',
        'Ver': 'View',
        'Pedido': 'Order',

        // Estados
        'Pendiente': 'Pending',
        'En proceso': 'Processing',
        'Enviado': 'Shipped',
        'Entregado': 'Delivered',
        'Cancelado': 'Cancelled',

        // Admin
        'Panel administrador GC': 'GC Admin panel',
        'Panel administrativo': 'Admin dashboard',
        'Acceso administrador': 'Admin access',
        'Credenciales incorrectas o no tienes rol de administrador.':
            'Incorrect credentials or you do not have administrator role.',
        '← Volver a la tienda': '← Back to store',
        'Productos': 'Products',
        'Pedidos': 'Orders',
        'Dashboard': 'Dashboard',
        'Productos con inventario bajo': 'Low-stock products',
        'Últimos pedidos registrados': 'Latest orders',
        'Estado de los pedidos': 'Order status',
        'Agregar producto': 'Add product',
        'Editar producto': 'Edit product',
        'Guardar': 'Save',
        'Cancelar': 'Cancel',
        'Eliminar': 'Delete',
        'Activo': 'Active',
        'Inactivo': 'Inactive',
        'Stock': 'Stock',
        'Stock mínimo': 'Minimum stock',
        'Descripción': 'Description',
        'Imagen': 'Image',
        'Descuento': 'Discount',
        'Acciones': 'Actions',
        'Ver tienda': 'View store',

        // Footer
        'GC — Ropa Original': 'GC — Original Clothing',
        'Proyecto académico UTS · Tecnólogo en Análisis y Desarrollo de Software':
            'Academic project UTS · Software Analysis and Development',
    };

    const ATRIBUTOS = ['placeholder', 'title'];

    function traducirNodoTexto(nodo) {
        const original = nodo.nodeValue.trim();
        if (DICCIONARIO[original]) {
            nodo.nodeValue = nodo.nodeValue.replace(original, DICCIONARIO[original]);
        }
    }

    function recorrer(el) {
        el.childNodes.forEach((nodo) => {
            if (nodo.nodeType === Node.TEXT_NODE) {
                traducirNodoTexto(nodo);
            } else if (nodo.nodeType === Node.ELEMENT_NODE) {
                if (nodo.closest && nodo.closest('[data-no-i18n]')) return;
                recorrer(nodo);
            }
        });
    }

    recorrer(document.body);

    document.querySelectorAll('[placeholder],[title]').forEach((el) => {
        ATRIBUTOS.forEach((attr) => {
            const val = el.getAttribute(attr);
            if (val && DICCIONARIO[val]) el.setAttribute(attr, DICCIONARIO[val]);
        });
    });
});
