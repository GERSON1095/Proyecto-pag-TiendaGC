<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Cambiar idioma (debe ir ANTES de cualquier salida HTML)
if (isset($_GET['lang']) && in_array($_GET['lang'], ['es', 'en'])) {
    setcookie("lang", $_GET['lang'], time() + (86400 * 30), "/");
    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
    exit;
}

require_once 'includes/lang.php'; // ya deja $lang y $textos listos, con t()

$paginaActual = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="<?= $lang ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GC | <?= t('titulo') ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/chatbot.css" rel="stylesheet">
    <script>window.GC_LANG = "<?= $lang ?>";</script>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark gc-navbar sticky-top">
    <div class="container">
        <a class="navbar-brand fw-bold" href="index.php">GC<span class="text-danger">.</span></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#gcNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="gcNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link <?= $paginaActual === 'index.php' ? 'active' : '' ?>" href="index.php"><?= t('inicio') ?></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $paginaActual === 'reporte.php' ? 'active' : '' ?>" href="reporte.php">
                        <i class="bi bi-bar-chart-line"></i> <?= t('reporte') ?>
                    </a>
                </li>
            </ul>
            <div class="d-flex align-items-center gap-3">
                <?php if (!empty($_SESSION['cliente_id'])): ?>
                    <span class="text-light small">
                        <i class="bi bi-person-check-fill"></i> <?= t('hola') ?>, <?= htmlspecialchars($_SESSION['cliente_nombre']) ?>
                    </span>
                    <a href="mis_pedidos.php" class="text-light small"><?= t('mis_pedidos') ?></a>
                    <a href="logout_cliente.php" class="text-light small"><?= t('cerrar_sesion') ?></a>
                <?php else: ?>
                    <a href="login_cliente.php" class="text-light small"><?= t('iniciar_sesion') ?></a>
                    <a href="registro.php" class="btn btn-sm btn-outline-light"><?= t('registrarme') ?></a>
                <?php endif; ?>
                <a href="carrito.php" class="text-light position-relative">
                    <i class="bi bi-bag fs-5"></i>
                    <span class="badge bg-danger rounded-pill position-absolute top-0 start-100 translate-middle">
                        <?= array_sum($_SESSION['carrito'] ?? []) ?>
                    </span>
                </a>
            </div>
        </div>
    </div>
</nav>

<div class="text-end p-2">
    <a href="?lang=es" class="<?= $lang === 'es' ? 'fw-bold' : '' ?>">🇪🇸 Español</a> |
    <a href="?lang=en" class="<?= $lang === 'en' ? 'fw-bold' : '' ?>">🇬🇧 English</a>
</div>