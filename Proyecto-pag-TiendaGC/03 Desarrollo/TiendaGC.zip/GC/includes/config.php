<?php
/**
 * Configuración de la IA conversacional (API de Anthropic / Claude).
 *
 * 1. Crea una cuenta en https://console.anthropic.com
 * 2. Genera una API key en "API Keys"
 * 3. Pégala abajo, reemplazando "TU_API_KEY_AQUI"
 *
 * IMPORTANTE: este archivo NUNCA debe subirse a un repositorio público
 * (GitHub, etc.) porque expondría tu clave. Si usas Git, agrégalo a
 * tu .gitignore.
 */

define('ANTHROPIC_API_KEY', 'TU_API_KEY_AQUI');

// Modelo a usar. claude-haiku-4-5-20251001 es el más económico y es
// suficiente para un chatbot de atención al cliente. Si quieres respuestas
// de mayor calidad (a más costo), puedes cambiarlo por 'claude-sonnet-5'.
define('ANTHROPIC_MODEL', 'claude-haiku-4-5-20251001');

/**
 * Clave para entrar al panel de administración (/admin).
 * Cámbiala por algo que solo tú conozcas antes de sustentar el proyecto.
 */
define('ADMIN_PASSWORD', 'gc2026admin');

/**
 * Clave usada para cifrar los datos PRIVADOS de los clientes
 * (teléfono, dirección) antes de guardarlos en la base de datos,
 * como parte de la clasificación de la información del proyecto.
 * Cámbiala por una propia y no la compartas.
 */
define('ENCRYPTION_KEY', 'GC-Tienda-2026-Clave-Cifrado-UTS');