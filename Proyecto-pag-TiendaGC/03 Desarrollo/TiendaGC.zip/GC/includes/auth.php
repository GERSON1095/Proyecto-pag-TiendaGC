<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Corta la ejecución y redirige a login.php si no hay sesión de admin activa.
 * Se llama al inicio de cada página protegida del panel /admin.
 */
function requiereLogin(): void
{
    if (empty($_SESSION['admin_autenticado'])) {
        header('Location: login.php');
        exit;
    }
}