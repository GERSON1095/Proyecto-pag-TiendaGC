<?php
/**
 * Conexión a la base de datos MySQL gestionada por XAMPP.
 * Por defecto, XAMPP usa el usuario "root" sin contraseña.
 * Antes de usar, importa database/gc_tienda.sql desde phpMyAdmin.
 */

$DB_HOST = "localhost";
$DB_NAME = "gc_tienda";
$DB_USER = "root";
$DB_PASS = "";

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]
    );
} catch (PDOException $e) {
    // Si la base de datos aún no existe, el sitio sigue funcionando
    // con los productos de ejemplo en memoria.
    $pdo = null;
}
