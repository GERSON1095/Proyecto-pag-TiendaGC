<footer class="gc-footer text-center py-4 mt-5">
    <div class="container">
        <p class="mb-1 fw-bold"><?= t('footer_marca') ?></p>
        <p class="mb-1 small text-secondary"><?= t('footer_proyecto') ?></p>
        <a href="politica-datos.php" class="small text-secondary"><?= t('politica_datos') ?></a>
    </div>
</footer>

<?php include 'includes/chatbot.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="js/main.js"></script>
<script src="js/chatbot.js"></script>
<script src="js/i18n.js"></script>
</body>
</html>
