<!-- Widget del chatbot: botón flotante abajo a la derecha -->
<div id="gc-chat-widget">
    <button id="gc-chat-toggle" class="gc-chat-btn" title="¿Necesitas ayuda?">
        <i class="bi bi-chat-dots-fill"></i>
    </button>

    <div id="gc-chat-window" class="gc-chat-window d-none">
        <div class="gc-chat-header d-flex justify-content-between align-items-center">
            <div class="d-flex align-items-center gap-2">
                <i class="bi bi-robot fs-5"></i>
                <div>
                    <div class="fw-bold small">Asistente GC</div>
                    <div class="gc-chat-status small">En línea</div>
                </div>
            </div>
            <button id="gc-chat-close" class="btn-close btn-close-white" aria-label="Cerrar"></button>
        </div>

        <div id="gc-chat-mensajes" class="gc-chat-mensajes"></div>

        <div id="gc-chat-rating" class="gc-chat-rating d-none">
            <p class="small mb-2 mt-2">¿Cómo calificarías esta atención?</p>
            <div class="d-flex gap-2 flex-wrap pb-2">
                <button class="btn btn-sm btn-outline-success" data-calificacion="Excelente">Excelente</button>
                <button class="btn btn-sm btn-outline-success" data-calificacion="Buena">Buena</button>
                <button class="btn btn-sm btn-outline-warning" data-calificacion="Regular">Regular</button>
                <button class="btn btn-sm btn-outline-danger" data-calificacion="Mala">Mala</button>
            </div>
        </div>

        <form id="gc-chat-form" class="gc-chat-form">
            <input type="text" id="gc-chat-input" class="form-control" placeholder="Escribe tu pregunta..." autocomplete="off">
            <button type="submit" class="btn btn-danger"><i class="bi bi-send"></i></button>
        </form>
    </div>
</div>
