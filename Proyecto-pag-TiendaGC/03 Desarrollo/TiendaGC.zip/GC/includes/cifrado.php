<?php
require_once __DIR__ . '/config.php';

/** Deriva una clave de 32 bytes (AES-256) a partir de la clave definida en config.php */
function claveDerivada(): string
{
    return hash('sha256', ENCRYPTION_KEY, true);
}

/** Cifra un dato privado (ej. teléfono, dirección) antes de guardarlo en la BD */
function cifrar(string $texto): string
{
    $iv = openssl_random_pseudo_bytes(16);
    $cifrado = openssl_encrypt($texto, 'AES-256-CBC', claveDerivada(), OPENSSL_RAW_DATA, $iv);
    return base64_encode($iv . $cifrado);
}

/** Descifra un dato guardado con cifrar(). Devuelve '' si no hay valor o falla. */
function descifrar(?string $textoCifrado): string
{
    if (!$textoCifrado) {
        return '';
    }
    $datos = base64_decode($textoCifrado);
    $iv = substr($datos, 0, 16);
    $cifrado = substr($datos, 16);
    $resultado = openssl_decrypt($cifrado, 'AES-256-CBC', claveDerivada(), OPENSSL_RAW_DATA, $iv);
    return $resultado !== false ? $resultado : '';
}