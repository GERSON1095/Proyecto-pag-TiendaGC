<?php
session_start();
header('Content-Type: application/json; charset=utf-8');
require_once 'includes/db.php';
require_once 'includes/config.php';
require_once 'includes/cifrado.php';

$lang = isset($_COOKIE['lang']) && in_array($_COOKIE['lang'], ['es', 'en']) ? $_COOKIE['lang'] : 'es';

$msjChat = [
    'es' => [
        'vacio'         => 'Escribe tu pregunta y con gusto te ayudo 🙂',
        'pedido_no_encontrado' => "No encontré ningún pedido con la referencia **%s** 🤔. Verifica que esté bien escrita (formato GC-XXXXXXXX) e inténtalo de nuevo.",
        'pedido_pide_ref' => "Claro, con gusto reviso tu pedido 📦 ¿Me compartes tu número de referencia? Es el código que te dimos al confirmar la compra, con el formato **GC-XXXXXXXX**.",
        'pedido_encontrado' => "Encontré tu pedido **%s** 📦",
        'total'         => 'Total',
        'direccion'     => 'Dirección de envío',
        'estado'        => 'Estado',
        'saludo'        => "¡Hola! Soy el asistente virtual de GC 👋. Puedo ayudarte a buscar productos, ver tallas y precios, o resolver dudas de pedidos, pagos y devoluciones. ¿Qué necesitas?",
        'disponible'    => "Esto tenemos disponible:",
        'mas_detalles'  => "¿Quieres más detalles de alguno o buscar algo más?",
        'antes'         => 'antes',
        'hoy'           => 'hoy',
        'sin_descuento_cat' => "Por ahora no hay descuentos en esa categoría, pero cuéntame qué buscas y te muestro las mejores opciones disponibles.",
        'sin_producto'  => "Por ahora no tengo ese producto exacto en el catálogo, pero cuéntame qué otra prenda buscas y te muestro opciones.",
        'envio'         => "Los envíos a nivel nacional tardan entre 2 y 5 días hábiles. El costo exacto se calcula según tu ciudad al finalizar la compra.",
        'cambios'       => "Tienes hasta 15 días calendario después de recibir tu pedido para solicitar un cambio o devolución, siempre que el producto esté sin uso y con sus etiquetas originales.",
        'pago'          => "Aceptamos tarjetas de crédito/débito, PSE y pago contraentrega en las principales ciudades.",
        'horario'       => "Nuestro equipo humano atiende de lunes a sábado de 9:00 a.m. a 6:00 p.m. Si quieres, puedo dejar tu consulta registrada para que te contacten.",
        'no_entendi'    => "No estoy seguro de haber entendido 🤔. Puedes preguntarme por hoodies, sneakers, gorras, camisas o pantalones, o sobre envíos, pagos y devoluciones.",
    ],
    'en' => [
        'vacio'         => 'Type your question and I\'ll gladly help 🙂',
        'pedido_no_encontrado' => "I couldn't find any order with reference **%s** 🤔. Check that it's typed correctly (format GC-XXXXXXXX) and try again.",
        'pedido_pide_ref' => "Sure, happy to check your order 📦 Can you share your reference number? It's the code we gave you when you confirmed your purchase, in the format **GC-XXXXXXXX**.",
        'pedido_encontrado' => "I found your order **%s** 📦",
        'total'         => 'Total',
        'direccion'     => 'Shipping address',
        'estado'        => 'Status',
        'saludo'        => "Hi! I'm GC's virtual assistant 👋. I can help you find products, check sizes and prices, or answer questions about orders, payments and returns. What do you need?",
        'disponible'    => "Here's what we have available:",
        'mas_detalles'  => "Want more details on any of these, or looking for something else?",
        'antes'         => 'was',
        'hoy'           => 'now',
        'sin_descuento_cat' => "There are no discounts in that category right now, but tell me what you're looking for and I'll show you the best options available.",
        'sin_producto'  => "I don't have that exact product in the catalog right now, but tell me what other item you're looking for and I'll show you options.",
        'envio'         => "Domestic shipping takes 2 to 5 business days. The exact cost is calculated based on your city at checkout.",
        'cambios'       => "You have up to 15 calendar days after receiving your order to request an exchange or return, as long as the product is unused and has its original tags.",
        'pago'          => "We accept credit/debit cards, PSE, and cash on delivery in major cities.",
        'horario'       => "Our human team is available Monday to Saturday, 9:00 a.m. to 6:00 p.m. If you'd like, I can log your question so they can contact you.",
        'no_entendi'    => "I'm not sure I understood that 🤔. You can ask me about hoodies, sneakers, caps, shirts or pants, or about shipping, payments and returns.",
    ],
];

/**
 * Catálogo de referencia si no hay conexión a MySQL.
 * Incluye descuento (0 = sin descuento) para que la IA pueda
 * recomendar productos en oferta.
 */
$productosRef = [
    ['nombre' => 'Hoodie Essential', 'marca' => 'Nike', 'categoria' => 'Hoodies', 'precio' => 189900, 'descuento' => 0],
    ['nombre' => 'Hoodie Trefoil', 'marca' => 'Adidas', 'categoria' => 'Hoodies', 'precio' => 175900, 'descuento' => 15],
    ['nombre' => 'Sneaker Air Max', 'marca' => 'Nike', 'categoria' => 'Sneakers', 'precio' => 429900, 'descuento' => 0],
    ['nombre' => 'Sneaker Ultraboost', 'marca' => 'Adidas', 'categoria' => 'Sneakers', 'precio' => 599900, 'descuento' => 0],
    ['nombre' => 'Sneaker RS-X', 'marca' => 'Puma', 'categoria' => 'Sneakers', 'precio' => 349900, 'descuento' => 10],
    ['nombre' => 'Gorra Snapback', 'marca' => 'Nike', 'categoria' => 'Gorras', 'precio' => 79900, 'descuento' => 20],
    ['nombre' => 'Gorra Trefoil', 'marca' => 'Adidas', 'categoria' => 'Gorras', 'precio' => 74900, 'descuento' => 0],
    ['nombre' => 'Camisa Deportiva Dri-FIT', 'marca' => 'Nike', 'categoria' => 'Camisas', 'precio' => 129900, 'descuento' => 0],
    ['nombre' => 'Camisa Puma Active', 'marca' => 'Puma', 'categoria' => 'Camisas', 'precio' => 109900, 'descuento' => 10],
    ['nombre' => 'Pantalón Jogger Tiro', 'marca' => 'Adidas', 'categoria' => 'Pantalones', 'precio' => 159900, 'descuento' => 0],
    ['nombre' => 'Pantalón Jogger Sportswear', 'marca' => 'Nike', 'categoria' => 'Pantalones', 'precio' => 169900, 'descuento' => 0],
    ['nombre' => 'Pantalón Puma Fit', 'marca' => 'Puma', 'categoria' => 'Pantalones', 'precio' => 149900, 'descuento' => 0],
];

if ($pdo) {
    try {
        $productosRef = $pdo->query("SELECT nombre, marca, categoria, precio, descuento, tallas, colores FROM productos")->fetchAll();
    } catch (PDOException $e) {
        // seguimos con el catálogo de ejemplo si la columna/tabla aún no existe
    }
}

$input = json_decode(file_get_contents('php://input'), true);
$accion = $input['accion'] ?? 'mensaje';

// ---------------------------------------------------------
// Acción: calificar la atención al finalizar la conversación
// ---------------------------------------------------------
if ($accion === 'calificar') {
    $calificacion = $input['calificacion'] ?? null;
    $validas = ['Excelente', 'Buena', 'Regular', 'Mala'];

    if ($pdo && isset($_SESSION['atencion_id']) && in_array($calificacion, $validas, true)) {
        $stmt = $pdo->prepare("UPDATE atenciones_chatbot SET calificacion = ? WHERE id = ?");
        $stmt->execute([$calificacion, $_SESSION['atencion_id']]);
    }

    echo json_encode(['ok' => true]);
    exit;
}

// ---------------------------------------------------------
// Acción: procesar un mensaje del cliente
// ---------------------------------------------------------
$mensaje = trim($input['mensaje'] ?? '');

if ($mensaje === '') {
    echo json_encode(['respuesta' => $msjChat[$lang]['vacio'], 'tipo' => 'otro']);
    exit;
}

$tipo = clasificarConsulta(quitarAcentos(mb_strtolower($mensaje, 'UTF-8')));

// Guarda o actualiza el registro de esta conversación (para el reporte mensual).
// Se hace ANTES de resolver la respuesta para que toda interacción cuente,
// incluidas las consultas de pedido resueltas sin IA.
registrarAtencion($pdo, $tipo);

// -----------------------------------------------------------------
// Consulta de pedidos por número de referencia (sin necesidad de login).
// Se resuelve directamente contra la base de datos, ANTES de llamar a la
// IA, para garantizar que la información (total, dirección, estado) sea
// siempre exacta y nunca "inventada" por el modelo.
// -----------------------------------------------------------------
$referenciaEnMensaje = detectarReferenciaPedido($mensaje);
if ($referenciaEnMensaje && $pdo) {
    $respuestaPedido = buscarPedidoPorReferencia($pdo, $referenciaEnMensaje, $lang, $msjChat);
    guardarEnHistorial($mensaje, $respuestaPedido);
    echo json_encode(['respuesta' => $respuestaPedido, 'tipo' => 'pedido']);
    exit;
}

if ($pdo && esConsultaDePedidoSinReferencia(quitarAcentos(mb_strtolower($mensaje, 'UTF-8')))) {
    $respuestaPedido = $msjChat[$lang]['pedido_pide_ref'];
    guardarEnHistorial($mensaje, $respuestaPedido);
    echo json_encode(['respuesta' => $respuestaPedido, 'tipo' => 'pedido']);
    exit;
}

// Historial de la conversación en sesión (memoria de contexto)
if (!isset($_SESSION['historial'])) {
    $_SESSION['historial'] = [];
}
$_SESSION['historial'][] = ['role' => 'user', 'content' => $mensaje];

// Solo mandamos los últimos 12 mensajes a la API para no gastar tokens de más
$historialReciente = array_slice($_SESSION['historial'], -12);

$respuesta = null;
if (defined('ANTHROPIC_API_KEY') && ANTHROPIC_API_KEY !== 'TU_API_KEY_AQUI') {
    $respuesta = consultarIA($historialReciente, $productosRef, $lang);
}
if ($respuesta === null) {
    $respuesta = generarRespuestaReglas(quitarAcentos(mb_strtolower($mensaje, 'UTF-8')), $productosRef, $lang, $msjChat);
}

$_SESSION['historial'][] = ['role' => 'assistant', 'content' => $respuesta];

echo json_encode(['respuesta' => $respuesta, 'tipo' => $tipo]);

// ===========================================================
// Consulta de pedidos por número de referencia
// ===========================================================

/** Busca un patrón tipo "GC-7K2P9XAB" en el mensaje del cliente */
function detectarReferenciaPedido(string $mensaje): ?string
{
    if (preg_match('/GC-[A-Z0-9]{6,10}/i', $mensaje, $coincidencias)) {
        return strtoupper($coincidencias[0]);
    }
    return null;
}

/** Detecta si preguntan por su pedido pero sin dar el número de referencia */
function esConsultaDePedidoSinReferencia(string $msgNorm): bool
{
    return (bool) preg_match(
        '/mi pedido|estado de mi pedido|donde esta mi pedido|rastrear|seguimiento|numero de pedido|numero de referencia|numero de orden/u',
        $msgNorm
    );
}

/** Busca el pedido en la BD y arma la respuesta con producto(s), total, dirección y estado */
function buscarPedidoPorReferencia(PDO $pdo, string $referencia, string $lang, array $msjChat): string
{
    $stmt = $pdo->prepare("SELECT * FROM pedidos WHERE numero_referencia = ?");
    $stmt->execute([$referencia]);
    $pedido = $stmt->fetch();

    if (!$pedido) {
        return sprintf($msjChat[$lang]['pedido_no_encontrado'], $referencia);
    }

    $stmt = $pdo->prepare("SELECT nombre_producto, cantidad, subtotal FROM detalle_pedido WHERE pedido_id = ?");
    $stmt->execute([$pedido['id']]);
    $items = $stmt->fetchAll();

    $listaProductos = implode("\n", array_map(function ($item) {
        return "- {$item['nombre_producto']} × {$item['cantidad']} — $" . number_format((float) $item['subtotal'], 0, ',', '.');
    }, $items));

    $direccion = descifrar($pedido['direccion_envio_cifrada']);

    return sprintf($msjChat[$lang]['pedido_encontrado'], $referencia) . "\n"
        . $listaProductos . "\n"
        . "**{$msjChat[$lang]['total']}:** $" . number_format((float) $pedido['total'], 0, ',', '.') . "\n"
        . "**{$msjChat[$lang]['direccion']}:** {$direccion}\n"
        . "**{$msjChat[$lang]['estado']}:** {$pedido['estado']}";
}

/** Inserta o actualiza el registro de la conversación en atenciones_chatbot (para el reporte mensual) */
function registrarAtencion(?PDO $pdo, string $tipo): void
{
    if (!$pdo) {
        return;
    }
    try {
        if (!isset($_SESSION['atencion_id'])) {
            $stmt = $pdo->prepare("INSERT INTO atenciones_chatbot (tipo_consulta) VALUES (?)");
            $stmt->execute([$tipo]);
            $_SESSION['atencion_id'] = (int) $pdo->lastInsertId();
        } else {
            $stmt = $pdo->prepare("UPDATE atenciones_chatbot SET tipo_consulta = ? WHERE id = ?");
            $stmt->execute([$tipo, $_SESSION['atencion_id']]);
        }
    } catch (PDOException $e) {
        // si la tabla no existe todavía, el chat sigue funcionando sin registrar
    }
}

/** Guarda el intercambio (usuario + bot) en el historial de sesión, igual que el flujo normal */
function guardarEnHistorial(string $mensajeUsuario, string $respuestaBot): void
{
    if (!isset($_SESSION['historial'])) {
        $_SESSION['historial'] = [];
    }
    $_SESSION['historial'][] = ['role' => 'user', 'content' => $mensajeUsuario];
    $_SESSION['historial'][] = ['role' => 'assistant', 'content' => $respuestaBot];
}

// ===========================================================
// IA conversacional (API de Claude / Anthropic)
// ===========================================================

function consultarIA(array $historial, array $productos, string $lang): ?string
{
    $catalogoTexto = implode("\n", array_map(function ($p) {
        // ... (igual que antes, sin cambios)
    }, $productos));

    $instruccionIdioma = $lang === 'en'
        ? "IMPORTANT: Respond ONLY in English, regardless of the language the customer writes in."
        : "IMPORTANTE: Responde ÚNICAMENTE en español, sin importar el idioma en que escriba el cliente.";

    $reglaIdioma = $lang === 'en'
        ? "- Give short answers (max 4-5 lines), in English, using **bold** for product names and \"- \" at the start of a line for lists when showing multiple options."
        : "- Da respuestas breves (máximo 4-5 líneas), en español, usando **negritas** para nombres de productos y \"- \" al inicio de línea para listas cuando muestres varias opciones.";

    $systemPrompt = <<<PROMPT
{$instruccionIdioma}

Eres el asistente virtual de GC, una tienda en línea de ropa y calzado 100% original de marcas como Nike, Adidas y Puma.

Tu tono es cercano, entusiasta y servicial, con emojis ocasionales (sin exagerar). Ayudas a los clientes a encontrar productos, resolver dudas de envíos, pagos, tallas, cambios y devoluciones, y a decidir qué comprar.

Reglas importantes:
- SOLO recomienda productos que estén en el catálogo de abajo. Nunca inventes productos, tallas, colores ni precios que no aparezcan ahí.
- Si te preguntan por tallas o colores de un producto, respóndelo con la información exacta del catálogo. Si un producto no tiene tallas/colores especificados, dilo con honestidad.
- Si un producto tiene descuento, menciónalo claramente (precio antes/después).
- Si no encuentras algo en el catálogo, dilo con honestidad y sugiere alternativas parecidas que sí existan.
{$reglaIdioma}
- Termina casi siempre con una pregunta corta para seguir ayudando.
- Políticas de la tienda: envíos nacionales 2 a 5 días hábiles; cambios y devoluciones hasta 15 días calendario con producto sin uso y etiquetas; métodos de pago: tarjeta, PSE y contraentrega en ciudades principales; atención humana lunes a sábado 9am-6pm.

Catálogo actual:
{$catalogoTexto}
PROMPT;


    $payload = json_encode([
        'model' => ANTHROPIC_MODEL,
        'max_tokens' => 400,
        'system' => $systemPrompt,
        'messages' => array_map(fn($m) => ['role' => $m['role'], 'content' => $m['content']], $historial),
    ]);

    $ch = curl_init('https://api.anthropic.com/v1/messages');
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => [
            'Content-Type: application/json',
            'x-api-key: ' . ANTHROPIC_API_KEY,
            'anthropic-version: 2023-06-01',
        ],
        CURLOPT_TIMEOUT => 20,
    ]);

    $respuestaCruda = curl_exec($ch);
    $error = curl_error($ch);
    $codigoHttp = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($error || $codigoHttp !== 200 || !$respuestaCruda) {
        error_log("Error IA chatbot GC: HTTP $codigoHttp - $error - $respuestaCruda");
        return null; // el llamador usará el respaldo por reglas
    }

    $data = json_decode($respuestaCruda, true);
    $texto = '';
    foreach ($data['content'] ?? [] as $bloque) {
        if (($bloque['type'] ?? '') === 'text') {
            $texto .= $bloque['text'];
        }
    }

    return $texto !== '' ? $texto : null;
}

// ===========================================================
// Respaldo sin IA (motor de reglas) — se usa si no hay API key
// configurada o si falla la conexión a la API.
// ===========================================================

function quitarAcentos(string $texto): string
{
    $mapa = [
        'á' => 'a', 'é' => 'e', 'í' => 'i', 'ó' => 'o', 'ú' => 'u',
        'à' => 'a', 'è' => 'e', 'ì' => 'i', 'ò' => 'o', 'ù' => 'u',
        'ä' => 'a', 'ë' => 'e', 'ï' => 'i', 'ö' => 'o', 'ü' => 'u',
        'ñ' => 'n',
    ];
    return strtr($texto, $mapa);
}

function detectarCategoria(string $msgNorm): ?string
{
    $mapa = [
        'hoodies' => 'Hoodies', 'hoodie' => 'Hoodies', 'buzos' => 'Hoodies', 'buzo' => 'Hoodies', 'sudaderas' => 'Hoodies', 'sudadera' => 'Hoodies',
        'sneakers' => 'Sneakers', 'sneaker' => 'Sneakers', 'tenis' => 'Sneakers', 'zapatillas' => 'Sneakers', 'zapatilla' => 'Sneakers', 'zapatos' => 'Sneakers', 'zapato' => 'Sneakers',
        'gorras' => 'Gorras', 'gorra' => 'Gorras', 'cachuchas' => 'Gorras', 'cachucha' => 'Gorras',
        'camisas' => 'Camisas', 'camisa' => 'Camisas', 'camisetas' => 'Camisas', 'camiseta' => 'Camisas',
        'pantalones' => 'Pantalones', 'pantalon' => 'Pantalones', 'joggers' => 'Pantalones', 'jogger' => 'Pantalones',
    ];
    $claves = array_keys($mapa);
    usort($claves, fn($a, $b) => mb_strlen($b) - mb_strlen($a));
    foreach ($claves as $clave) {
        if (preg_match('/\b' . preg_quote($clave, '/') . '\b/u', $msgNorm)) {
            return $mapa[$clave];
        }
    }
    return null;
}

function detectarMarca(string $msgNorm): ?string
{
    $marcas = ['nike' => 'Nike', 'adidas' => 'Adidas', 'puma' => 'Puma'];
    foreach ($marcas as $clave => $nombre) {
        if (preg_match('/\b' . preg_quote($clave, '/') . '\b/u', $msgNorm)) {
            return $nombre;
        }
    }
    return null;
}

function clasificarConsulta(string $msgNorm): string
{
    if (preg_match('/pedido|orden|envio|rastre|estado de mi compra/u', $msgNorm)) return 'pedido';
    if (preg_match('/devolucion|cambio|garantia|danado|defectuoso/u', $msgNorm)) return 'devolucion';
    if (detectarCategoria($msgNorm) || detectarMarca($msgNorm) || preg_match('/precio|talla|producto|catalogo|cuesta|vale|descuento|oferta/u', $msgNorm)) return 'producto';
    if (preg_match('/pago|tarjeta|factura|pse/u', $msgNorm)) return 'pago';
    return 'otro';
}

function generarRespuestaReglas(string $msgNorm, array $productos, string $lang, array $msjChat): string
{
    $T = $msjChat[$lang];

    if (preg_match('/^(hola|buenas|hey|que tal|buenos dias|buenas tardes|hi|hello|hey there)/u', $msgNorm)) {
        return $T['saludo'];
    }

    $soloDescuento = (bool) preg_match('/descuento|oferta|rebaja|promocion|discount|sale/u', $msgNorm);
    $categoriaDetectada = detectarCategoria($msgNorm);
    $marcaDetectada = detectarMarca($msgNorm);

    if ($categoriaDetectada || $marcaDetectada || $soloDescuento) {
        $coincidencias = array_values(array_filter($productos, function ($p) use ($categoriaDetectada, $marcaDetectada, $soloDescuento) {
            $coincideCategoria = !$categoriaDetectada || $p['categoria'] === $categoriaDetectada;
            $coincideMarca = !$marcaDetectada || $p['marca'] === $marcaDetectada;
            $coincideDescuento = !$soloDescuento || ($p['descuento'] ?? 0) > 0;
            return $coincideCategoria && $coincideMarca && $coincideDescuento;
        }));

        if (!empty($coincidencias)) {
            $lista = array_map(function ($p) use ($T) {
                $descuento = $p['descuento'] ?? 0;
                if ($descuento > 0) {
                    $precioFinal = $p['precio'] * (1 - $descuento / 100);
                    return "- **{$p['nombre']}** ({$p['marca']}) — {$T['antes']} $" . number_format((float) $p['precio'], 0, ',', '.') . ", {$T['hoy']} -{$descuento}% = $" . number_format($precioFinal, 0, ',', '.');
                }
                return "- **{$p['nombre']}** ({$p['marca']}) — $" . number_format((float) $p['precio'], 0, ',', '.');
            }, array_slice($coincidencias, 0, 4));

            return $T['disponible'] . "\n" . implode("\n", $lista) . "\n" . $T['mas_detalles'];
        }

        return $soloDescuento ? $T['sin_descuento_cat'] : $T['sin_producto'];
    }

    if (preg_match('/envio|domicilio|cuanto tarda|cuando llega|shipping|delivery/u', $msgNorm)) return $T['envio'];
    if (preg_match('/cambio|devolucion|garantia|exchange|return|warranty/u', $msgNorm)) return $T['cambios'];
    if (preg_match('/pago|tarjeta|metodos? de pago|pse|payment|card/u', $msgNorm)) return $T['pago'];
    if (preg_match('/horario|humano|asesor|agente real|human|agent/u', $msgNorm)) return $T['horario'];

    return $T['no_entendi'];
}