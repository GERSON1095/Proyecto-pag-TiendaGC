<?php
require_once 'includes/db.php';
require_once 'includes/cifrado.php';

$errores = [];
$exito = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre = trim($_POST['nombre'] ?? '');
    $correo = trim($_POST['correo'] ?? '');
    $telefono = trim($_POST['telefono'] ?? '');
    $direccion = trim($_POST['direccion'] ?? '');
    $password = $_POST['password'] ?? '';
    $acepta = isset($_POST['acepta']);

    if ($nombre === '' || $correo === '' || $password === '') {
        $errores[] = 'error_campos_obli';
    }
    if (strlen($password) < 6) {
        $errores[] = 'error_pass_corta';
    }
    if (!$acepta) {
        $errores[] = 'error_acepta';
    }
    if (!$pdo) {
        $errores[] = 'error_sin_bd';
    }

    if (empty($errores)) {
        $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE correo = ?");
        $stmt->execute([$correo]);
        if ($stmt->fetch()) {
            $errores[] = 'error_correo_existe';
        }
    }

    if (empty($errores)) {
        $stmt = $pdo->prepare("
            INSERT INTO usuarios (
                nombre, correo, telefono_cifrado, direccion_cifrada,
                password_hash, rol, acepto_tratamiento_datos, fecha_aceptacion
            )
            VALUES (?, ?, ?, ?, ?, 'cliente', 1, NOW())
        ");
        $stmt->execute([
            $nombre,
            $correo,
            $telefono !== '' ? cifrar($telefono) : null,
            $direccion !== '' ? cifrar($direccion) : null,
            password_hash($password, PASSWORD_DEFAULT),
        ]);
        $exito = true;
    }
}

include 'includes/header.php';
?>

<section class="container my-5" style="max-width: 520px;">
    <h1 class="h4 mb-4"><?= t('registro_titulo') ?></h1>

    <?php if ($exito): ?>
        <div class="alert alert-success">
            <?= t('cuenta_creada') ?> <a href="login_cliente.php"><?= t('iniciar_sesion') ?></a>.
        </div>
    <?php else: ?>

        <?php if (!empty($errores)): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php foreach ($errores as $e): ?><li><?= htmlspecialchars(t($e)) ?></li><?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <form method="post" class="bg-white p-4 rounded shadow-sm">
            <div class="mb-3">
                <label class="form-label"><?= t('nombre_completo') ?></label>
                <input type="text" name="nombre" class="form-control" value="<?= htmlspecialchars($_POST['nombre'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?= t('correo') ?></label>
                <input type="email" name="correo" class="form-control" value="<?= htmlspecialchars($_POST['correo'] ?? '') ?>" required>
            </div>
            <div class="mb-3">
                <label class="form-label"><?= t('telefono') ?> <span class="text-secondary small"><?= t('opcional') ?></span></label>
                <input type="text" name="telefono" class="form-control" value="<?= htmlspecialchars($_POST['telefono'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label"><?= t('direccion_envio') ?> <span class="text-secondary small"><?= t('opcional') ?></span></label>
                <input type="text" name="direccion" class="form-control" value="<?= htmlspecialchars($_POST['direccion'] ?? '') ?>">
            </div>
            <div class="mb-3">
                <label class="form-label"><?= t('contrasena') ?></label>
                <input type="password" name="password" class="form-control" required minlength="6">
            </div>

            <div class="form-check mb-4">
                <input class="form-check-input" type="checkbox" name="acepta" id="acepta" value="1"
                       <?= isset($_POST['acepta']) ? 'checked' : '' ?>>
                <label class="form-check-label small" for="acepta">
                    <?= t('autorizo_datos') ?>
                    <a href="politica-datos.php" target="_blank"><?= t('politica_datos') ?></a> de GC.
                </label>
            </div>

            <button type="submit" class="btn btn-danger w-100"><?= t('crear_cuenta') ?></button>
        </form>

        <p class="text-center small mt-3">
            <?= t('ya_tienes_cuenta') ?> <a href="login_cliente.php"><?= t('iniciar_sesion') ?></a>
        </p>
    <?php endif; ?>
</section>

<?php include 'includes/footer.php'; ?>
