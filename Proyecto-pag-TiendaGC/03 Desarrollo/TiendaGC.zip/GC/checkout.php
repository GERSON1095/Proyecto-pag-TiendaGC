<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once 'includes/db.php';
require_once 'includes/cifrado.php';

if (empty($_SESSION['cliente_id'])) {
    header('Location: login_cliente.php');
    exit;
}
if (empty($_SESSION['carrito']) || !$pdo) {
    header('Location: carrito.php');
    exit;
}

// Recalculamos el total desde la base de datos (nunca confiamos en precios del navegador)
$ids = array_keys($_SESSION['carrito']);
$marcadores = implode(',', array_fill(0, count($ids), '?'));
$stmt = $pdo->prepare("SELECT id, nombre, precio, descuento FROM productos WHERE id IN ($marcadores)");
$stmt->execute($ids);
$productosCarrito = $stmt->fetchAll();

$total = 0;
foreach ($productosCarrito as $p) {
    $cantidad = $_SESSION['carrito'][$p['id']];
    $precioFinal = $p['precio'] * (1 - ($p['descuento'] ?? 0) / 100);
    $total += $precioFinal * $cantidad;
}

// Autocompletamos con la dirección guardada del cliente, si tiene una
$stmt = $pdo->prepare("SELECT nombre, direccion_cifrada FROM usuarios WHERE id = ?");
$stmt->execute([$_SESSION['usuario_id'] ?? $_SESSION['cliente_id']]);
$cliente = $stmt->fetch();
$direccionGuardada = $cliente && $cliente['direccion_cifrada'] ? descifrar($cliente['direccion_cifrada']) : '';

include 'includes/header.php';
?>

<section class="container my-5" style="max-width: 640px;">
    <h1 class="h4 mb-4"><?= t('finalizar_compra') ?></h1>

    <div class="alert alert-light border small">
        <?= t('total_a_pagar') ?>: <strong>$<?= number_format($total, 0, ',', '.') ?></strong>
    </div>

    <form action="procesar_pedido.php" method="post" class="bg-white p-4 rounded shadow-sm">

        <h2 class="h6 mb-3"><?= t('direccion_envio') ?></h2>
        <div class="mb-3">
            <label class="form-label"><?= t('direccion') ?></label>
            <input type="text" name="direccion" class="form-control" value="<?= htmlspecialchars($direccionGuardada) ?>" required>
        </div>
        <div class="mb-4">
            <label class="form-label"><?= t('ciudad') ?></label>
            <input type="text" name="ciudad" class="form-control" required>
        </div>

        <h2 class="h6 mb-3"><?= t('metodo_pago') ?></h2>
        <div class="mb-3">
            <select name="metodo_pago" id="metodoPago" class="form-select" required>
                <option value=""><?= t('selecciona') ?></option>
                <option value="Tarjeta"><?= t('tarjeta') ?></option>
                <option value="PSE"><?= t('pse') ?></option>
                <option value="Contraentrega"><?= t('contraentrega') ?></option>
            </select>
        </div>

        <div id="datosTarjeta" class="d-none mb-3">
            <div class="mb-3">
                <label class="form-label"><?= t('numero_tarjeta') ?></label>
                <input type="text" name="numero_tarjeta" class="form-control" maxlength="19" placeholder="•••• •••• •••• ••••">
            </div>
            <div class="row">
                <div class="col-6 mb-3">
                    <label class="form-label"><?= t('vencimiento') ?></label>
                    <input type="text" name="vencimiento" class="form-control" placeholder="MM/AA">
                </div>
                <div class="col-6 mb-3">
                    <label class="form-label"><?= t('cvv') ?></label>
                    <input type="text" name="cvv" class="form-control" maxlength="4" placeholder="•••">
                </div>
            </div>
        </div>

        <button type="submit" class="btn btn-danger w-100"><?= t('confirmar_pedido') ?></button>
    </form>
</section>

<script>
document.getElementById('metodoPago').addEventListener('change', function () {
    document.getElementById('datosTarjeta').classList.toggle('d-none', this.value !== 'Tarjeta');
});
</script>

<?php include 'includes/footer.php'; ?>
